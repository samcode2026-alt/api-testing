#!/bin/bash

# Minify script for SMD2 Testing Application
# Creates minified versions of HTML, CSS, and JS files in a 'dist' directory

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIST_DIR="$SCRIPT_DIR/dist"

echo "Creating dist directory..."
rm -rf "$DIST_DIR"
mkdir -p "$DIST_DIR"

# Function to minify CSS (basic - removes comments and whitespace)
minify_css() {
    local input="$1"
    local output="$2"
    echo "Minifying CSS: $input -> $output"
    # Remove comments, newlines, and extra whitespace
    sed -e 's|/\*[^*]*\*+([^/*][^*]*\*+)*/||g' \
        -e 's/^[ \t]*//g' \
        -e 's/[ \t]*$//g' \
        -e '/^$/d' \
        -e ':a;N;$!ba;s/\n//g' \
        -e 's/  */ /g' \
        -e 's/ *{ */{/g' \
        -e 's/ *} */}/g' \
        -e 's/ *: */:/g' \
        -e 's/ *; */;/g' \
        -e 's/ *, */,/g' \
        "$input" > "$output"
}

# Function to minify JS (basic - removes comments and extra whitespace)
minify_js() {
    local input="$1"
    local output="$2"
    echo "Minifying JS: $input -> $output"
    # Remove single-line comments (but preserve URLs), remove empty lines, collapse whitespace
    sed -e 's|//[^"'"'"']*$||g' \
        -e '/^[ \t]*$/d' \
        -e 's/^[ \t]*//g' \
        -e 's/[ \t]*$//g' \
        "$input" > "$output"
}

# Function to minify HTML (basic - removes extra whitespace between tags)
minify_html() {
    local input="$1"
    local output="$2"
    echo "Minifying HTML: $input -> $output"
    # Remove HTML comments, collapse whitespace between tags
    sed -e 's/<!--[^>]*-->//g' \
        -e 's/>[ \t]*</></g' \
        -e '/^[ \t]*$/d' \
        "$input" > "$output"
}

echo "========================================"
echo "Starting minification..."
echo "========================================"

# Copy and minify main files
if [ -f "$SCRIPT_DIR/smd2.html" ]; then
    minify_html "$SCRIPT_DIR/smd2.html" "$DIST_DIR/smd2.html"
fi

if [ -f "$SCRIPT_DIR/smd.css" ]; then
    minify_css "$SCRIPT_DIR/smd.css" "$DIST_DIR/smd.css"
fi

# Minify JavaScript files
for jsfile in "$SCRIPT_DIR"/*.js; do
    if [ -f "$jsfile" ]; then
        filename=$(basename "$jsfile")
        minify_js "$jsfile" "$DIST_DIR/$filename"
    fi
done

# Copy other static files
echo "Copying other files..."
for file in "$SCRIPT_DIR"/*.txt "$SCRIPT_DIR"/*.md; do
    if [ -f "$file" ]; then
        cp "$file" "$DIST_DIR/"
    fi
done

# Copy directories if they exist
for dir in certs clients queries; do
    if [ -d "$SCRIPT_DIR/$dir" ]; then
        echo "Copying directory: $dir"
        cp -r "$SCRIPT_DIR/$dir" "$DIST_DIR/"
    fi
done

# Show summary
echo "========================================"
echo "Minification complete!"
echo "========================================"
echo "Output directory: $DIST_DIR"
echo ""
echo "File sizes:"
echo "  Original smd2.html: $(wc -c < "$SCRIPT_DIR/smd2.html" 2>/dev/null || echo 'N/A') bytes"
echo "  Minified smd2.html: $(wc -c < "$DIST_DIR/smd2.html" 2>/dev/null || echo 'N/A') bytes"
echo ""
echo "  Original smd.css: $(wc -c < "$SCRIPT_DIR/smd.css" 2>/dev/null || echo 'N/A') bytes"
echo "  Minified smd.css: $(wc -c < "$DIST_DIR/smd.css" 2>/dev/null || echo 'N/A') bytes"
