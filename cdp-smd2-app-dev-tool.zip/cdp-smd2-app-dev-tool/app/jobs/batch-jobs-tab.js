// Batch Jobs Tab Module
// Renders the Batch Jobs tab with schedule summary and job history
// Requires: SMD2_JOBS, SMD2_ENVS globals
// Supports appConfig.tabs.batchJobs.enabled and appConfig.batchJobsSubTabs for configuration

(function(window) {
    'use strict';

    // Get appConfig from current active environment
    function getAppConfig(ENVS, envKeys) {
        const activeEnvBtn = document.querySelector('#current-env .env-toggle-btn.active');
        const env = activeEnvBtn ? activeEnvBtn.dataset.env : envKeys[0];
        return ENVS[env]?.appConfig || {};
    }

    // Check if a tab or feature is enabled
    function isEnabled(appConfig, section, key) {
        if (!appConfig || !appConfig[section] || !appConfig[section][key]) return true;
        return appConfig[section][key].enabled !== false;
    }

    function renderBatchJobsTab(tabsEl, panelsEl, ENVS, envKeys) {
        const jobs = window.SMD2_JOBS || [];
        if (!jobs.length) return;

        // Check if Batch Jobs tab is enabled in any environment's config
        const anyEnvEnabled = envKeys.some(env => {
            const cfg = ENVS[env]?.appConfig;
            return !cfg || !cfg.tabs || !cfg.tabs.batchJobs || cfg.tabs.batchJobs.enabled !== false;
        });
        if (!anyEnvEnabled) return;

        const groups = new Map();
        jobs.forEach(job => {
            const t = job.type || 'Other';
            if (!groups.has(t)) groups.set(t, []);
            groups.get(t).push(job);
        });

        const mainBtn = document.createElement('button');
        mainBtn.className = 'tab-button';
        mainBtn.dataset.tab = '__batchjobs__';
        mainBtn.setAttribute('role', 'tab');
        mainBtn.textContent = '⚡ Batch Jobs';
        tabsEl.appendChild(mainBtn);

        const panel = document.createElement('section');
        panel.id = '__batchjobs__';
        panel.className = 'tab-panel';
        panel.setAttribute('role', 'tabpanel');

        function getActiveJobEnv() {
            const active = document.querySelector('#current-env .env-toggle-btn.active');
            return active ? active.dataset.env : envKeys[0];
        }

        const subBar = document.createElement('div');
        subBar.style.cssText = 'display:flex;gap:4px;border-bottom:2px solid #ddd;margin:0.75rem 0 0;flex-wrap:wrap;';
        const subPanelsWrap = document.createElement('div');

        const typeIcons = {
            'Authorization & Delta': '🔑',
            'Batch Data':            '📦',
            'CAISO':                 '⚡',
            'CCB':                   '🛠️',
            'Migration':             '🚚',
            'Reports':               '📊',
            'Demand Response':       '🌡️',
            'Data Processing':       '🔄'
        };

        // Map type names to config keys
        const typeToConfigKey = {
            'Authorization & Delta': 'authorizationDelta',
            'Batch Data':            'batchData',
            'CAISO':                 'caiso',
            'CCB':                   'ccb',
            'Migration':             'migration',
            'Reports':               'reports',
            'Demand Response':       'demandResponse',
            'Data Processing':       'dataProcessing'
        };

        // Get current app config
        const appConfig = getAppConfig(ENVS, envKeys);
        const subTabConfig = appConfig.batchJobsSubTabs || {};

        // Schedule Summary sub-tab
        const summarySubId = '__bj_sub_summary__';
        const summaryEnabled = !subTabConfig.scheduleSummary || subTabConfig.scheduleSummary.enabled !== false;
        if (summaryEnabled) {
            const summarySubBtn = document.createElement('button');
            summarySubBtn.className = 'tab-button sub-tab-small active';
            summarySubBtn.dataset.subTab = summarySubId;
            summarySubBtn.textContent = '📅 Schedule Summary';
            subBar.appendChild(summarySubBtn);
        }

        // Job History sub-tab
        const historySubId = '__bj_sub_history__';
        const historyEnabled = !subTabConfig.jobHistory || subTabConfig.jobHistory.enabled !== false;
        if (historyEnabled) {
            const historySubBtn = document.createElement('button');
            historySubBtn.className = 'tab-button sub-tab-small' + (!summaryEnabled ? ' active' : '');
            historySubBtn.dataset.subTab = historySubId;
            historySubBtn.textContent = '📊 Job History';
            subBar.appendChild(historySubBtn);
        }

        const summaryPanel = document.createElement('div');
        summaryPanel.id = summarySubId;
        summaryPanel.className = 'cred-panel active';

        const batchConfig = window.SMD2_BATCH_JOBS_CONFIG || { timeFormat: '12h' };

        function formatTime(time24, format) {
            if (!time24 || time24 === '—') return '—';
            if (format === '24h') return time24;
            const [hours, minutes] = time24.split(':').map(Number);
            const period = hours >= 12 ? 'PM' : 'AM';
            const hours12 = hours % 12 || 12;
            return `${hours12}:${minutes.toString().padStart(2, '0')} ${period}`;
        }

        let currentSort = { column: 'startTime', direction: 'asc' };

        function getSortValue(job, column) {
            switch (column) {
                case 'type': return job.type || '';
                case 'schedulerType': return job.scheduler_type || 'UC4';
                case 'startTime': return job.schedule?.startTime || '99:99';
                default: return '';
            }
        }

        function sortJobs(jobsToSort, column, direction) {
            return [...jobsToSort].sort((a, b) => {
                const valA = getSortValue(a, column);
                const valB = getSortValue(b, column);
                const cmp = valA.localeCompare(valB);
                return direction === 'asc' ? cmp : -cmp;
            });
        }

        const summaryTable = document.createElement('table');
        summaryTable.className = 'cred-table bj-summary-table';
        const summaryThead = document.createElement('thead');
        summaryThead.innerHTML = `
            <tr>
                <th>Job Name</th>
                <th class="bj-sortable" data-sort="type">Type <span class="bj-sort-icon">⇅</span></th>
                <th class="bj-sortable" data-sort="schedulerType">Scheduler Type <span class="bj-sort-icon">⇅</span></th>
                <th>Schedule Days</th>
                <th class="bj-sortable bj-sort-active" data-sort="startTime">Start Time <span class="bj-sort-icon">↑</span></th>
                <th>Expected Runtime</th>
                <th>Summary</th>
            </tr>
        `;
        summaryTable.appendChild(summaryThead);
        const summaryTbody = document.createElement('tbody');

        function renderSummaryRows(sortedJobs) {
            summaryTbody.innerHTML = '';
            sortedJobs.forEach(job => {
                const sched = job.schedule || {};
                const schedulerType = job.scheduler_type || 'UC4';
                const schedulerBadgeClass = schedulerType === 'Anypoint Scheduler' ? 'anypoint' : (schedulerType === 'UC4' ? 'uc4' : 'rest');
                const displayTime = formatTime(sched.startTime, batchConfig.timeFormat);
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong>${job.name}</strong></td>
                    <td><span class="bj-type-badge">${typeIcons[job.type] || '📌'} ${job.type}</span></td>
                    <td><span class="bj-scheduler-badge ${schedulerBadgeClass}">${schedulerType}</span></td>
                    <td>${(sched.days || []).join(', ') || '—'}</td>
                    <td class="bj-time">${displayTime}</td>
                    <td>${sched.expectedRuntime || '—'}</td>
                    <td>${job.summary || '—'}</td>
                `;
                summaryTbody.appendChild(tr);
            });
        }

        renderSummaryRows(sortJobs(jobs, 'startTime', 'asc'));

        summaryThead.querySelectorAll('.bj-sortable').forEach(th => {
            th.style.cursor = 'pointer';
            th.addEventListener('click', () => {
                const col = th.dataset.sort;
                if (currentSort.column === col) {
                    currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
                } else {
                    currentSort.column = col;
                    currentSort.direction = 'asc';
                }
                summaryThead.querySelectorAll('.bj-sortable').forEach(h => {
                    h.classList.remove('bj-sort-active');
                    h.querySelector('.bj-sort-icon').textContent = '⇅';
                });
                th.classList.add('bj-sort-active');
                th.querySelector('.bj-sort-icon').textContent = currentSort.direction === 'asc' ? '↑' : '↓';
                renderSummaryRows(sortJobs(jobs, currentSort.column, currentSort.direction));
            });
        });

        summaryTable.appendChild(summaryTbody);
        if (summaryEnabled) {
            summaryPanel.appendChild(summaryTable);
            subPanelsWrap.appendChild(summaryPanel);
        }

        // Job History panel
        if (historyEnabled) {
            const historyPanel = buildJobHistoryPanel(jobs);
            historyPanel.id = historySubId;
            historyPanel.className = 'cred-panel' + (!summaryEnabled ? ' active' : '');
            subPanelsWrap.appendChild(historyPanel);
        }

        // Type-specific sub-tabs - check if enabled in config
        groups.forEach((groupJobs, typeName) => {
            const configKey = typeToConfigKey[typeName];
            const typeEnabled = !configKey || !subTabConfig[configKey] || subTabConfig[configKey].enabled !== false;
            if (!typeEnabled) return;

            const subId = `__bj_sub_${typeName.replace(/\W+/g, '_')}__`;
            const icon = typeIcons[typeName] || '📌';

            const subBtn = document.createElement('button');
            subBtn.className = 'tab-button sub-tab-small';
            subBtn.dataset.subTab = subId;
            subBtn.textContent = icon + ' ' + typeName;
            subBar.appendChild(subBtn);

            const subPanel = document.createElement('div');
            subPanel.id = subId;
            subPanel.className = 'cred-panel';

            groupJobs.forEach(job => {
                const card = buildJobCard(job, ENVS, getActiveJobEnv);
                subPanel.appendChild(card);
            });

            subPanelsWrap.appendChild(subPanel);
        });

        subBar.querySelectorAll('[data-sub-tab]').forEach(subBtn => {
            subBtn.addEventListener('click', () => {
                subBar.querySelectorAll('[data-sub-tab]').forEach(b => b.classList.toggle('active', b === subBtn));
                subPanelsWrap.querySelectorAll('.cred-panel').forEach(p => p.classList.toggle('active', p.id === subBtn.dataset.subTab));
            });
        });

        panel.appendChild(subBar);
        panel.appendChild(subPanelsWrap);
        panelsEl.appendChild(panel);

        // Update curl blocks when environment changes
        document.getElementById('current-env').addEventListener('click', e => {
            const btn = e.target.closest('.env-toggle-btn');
            if (!btn) return;
            const env = btn.dataset.env;
            panel.querySelectorAll('pre[data-bj-method]').forEach(el => {
                const batchBase = ENVS[env].batchBase || '';
                el.textContent = `curl -X ${el.dataset.bjMethod} \\\n  "${batchBase}${el.dataset.bjPath}" \\\n  -H "Authorization: Bearer {access_token}" \\\n  -H "Content-Type: application/json"`;
            });
        });
    }

    function buildJobCard(job, ENVS, getActiveJobEnv) {
        const card = document.createElement('div');
        card.className = 'bj-card';

        const cardHdr = document.createElement('div');
        cardHdr.className = 'bj-card-header';
        cardHdr.textContent = job.name;
        card.appendChild(cardHdr);

        const cardDesc = document.createElement('div');
        cardDesc.className = 'bj-card-desc';
        cardDesc.textContent = job.desc;
        card.appendChild(cardDesc);

        if (job.summary) {
            const summaryDiv = document.createElement('div');
            summaryDiv.className = 'bj-summary-text';
            summaryDiv.textContent = '📝 ' + job.summary;
            card.appendChild(summaryDiv);
        }

        // Config section
        const configSection = document.createElement('div');
        configSection.className = 'bj-config-section';
        const authType = job.auth_type || 'basic';
        const authBadgeClass = authType === 'jwt_bearer' ? 'jwt' : 'basic';
        const authLabel = authType === 'jwt_bearer' ? 'JWT Bearer' : 'Basic Auth';
        const schedulerType = job.scheduler_type || 'UC4';
        const schedulerBadgeClass = schedulerType === 'Anypoint Scheduler' ? 'anypoint' : (schedulerType === 'UC4' ? 'uc4' : 'rest');

        let configHtml = `
            <div class="bj-config-row">
                <div class="bj-config-item">
                    <span class="bj-config-label">🔐 Auth:</span>
                    <span class="bj-auth-badge ${authBadgeClass}">${authLabel}</span>
                </div>
                <div class="bj-config-item">
                    <span class="bj-config-label">⏱️ Scheduler:</span>
                    <span class="bj-scheduler-badge ${schedulerBadgeClass}">${schedulerType}</span>
                </div>
        `;
        if (authType === 'jwt_bearer' && job.cert_env_var) {
            configHtml += `
                <div class="bj-config-item">
                    <span class="bj-config-label">🗝️ Cert:</span>
                    <code class="bj-cert-badge">${job.cert_env_var}</code>
                </div>
            `;
        }
        configHtml += '</div>';
        configSection.innerHTML = configHtml;
        card.appendChild(configSection);

        // Schedule details
        if (job.schedule) {
            const schedWrap = document.createElement('div');
            schedWrap.className = 'bj-schedule-wrap';
            const sched = job.schedule;
            let schedHtml = `
                <div class="bj-schedule-item"><span class="bj-sched-label">📆 Days:</span> <span class="bj-sched-value">${(sched.days || []).join(', ')}</span></div>
                <div class="bj-schedule-item"><span class="bj-sched-label">⏰ Start:</span> <span class="bj-sched-value bj-time">${sched.startTime || '—'}${sched.timezone ? ' (' + sched.timezone + ')' : ''}</span></div>
                <div class="bj-schedule-item"><span class="bj-sched-label">⏱️ Runtime:</span> <span class="bj-sched-value">${sched.expectedRuntime || '—'}</span></div>
                <div class="bj-schedule-item"><span class="bj-sched-label">📨 Queue:</span> <code class="bj-queue">${sched.queue || '—'}</code></div>
            `;
            if (sched.cron) {
                schedHtml += `<div class="bj-schedule-item"><span class="bj-sched-label">🕐 CRON:</span> <code class="bj-queue">${sched.cron}</code></div>`;
            }
            schedWrap.innerHTML = schedHtml;
            card.appendChild(schedWrap);
        }

        // Application details (without downstream_apis - moved to Technical Details)
        if (job.application) {
            const appWrap = document.createElement('div');
            appWrap.className = 'bj-app-details';
            let appHtml = `<div class="bj-app-header">📱 Application Details</div><div class="bj-app-grid">`;
            appHtml += `<div class="bj-app-item"><span class="bj-app-label">App Name:</span> <code>${job.application.name}</code></div>`;
            if (job.application.job_name) {
                appHtml += `<div class="bj-app-item"><span class="bj-app-label">Job Name:</span> <code>${job.application.job_name}</code></div>`;
            }
            appHtml += '</div>';
            appWrap.innerHTML = appHtml;
            card.appendChild(appWrap);
        }

        // Technical details (collapsible) - includes downstream_apis
        const hasDownstreamApis = job.application?.downstream_apis?.length > 0;
        if (job.messaging || job.storage || job.processing || job.retry_policy || hasDownstreamApis) {
            const techWrap = document.createElement('div');
            techWrap.className = 'bj-tech-details bj-collapsible';
            const techHeader = document.createElement('button');
            techHeader.className = 'bj-collapsible-header';
            techHeader.innerHTML = `<span class="bj-collapse-icon">▶</span> ⚙️ Technical Configuration`;
            techHeader.type = 'button';
            const techContent = document.createElement('div');
            techContent.className = 'bj-collapsible-content';
            techContent.style.display = 'none';
            let techHtml = '<div class="bj-tech-grid">';
            if (hasDownstreamApis) {
                techHtml += `<div class="bj-tech-item bj-downstream-apis"><span class="bj-tech-label">🔗 Downstream APIs:</span><ul class="bj-api-list">`;
                job.application.downstream_apis.forEach(api => {
                    techHtml += `<li><code>${api}</code></li>`;
                });
                techHtml += '</ul></div>';
            }
            if (job.messaging) {
                techHtml += `<div class="bj-tech-item"><span class="bj-tech-label">Messaging:</span> ${job.messaging.type} (queue: <code>${job.messaging.queue}</code>)</div>`;
            }
            if (job.storage) {
                techHtml += `<div class="bj-tech-item"><span class="bj-tech-label">Storage:</span> ${job.storage.type} (folder: <code>${job.storage.folder}</code>)</div>`;
            }
            if (job.processing) {
                techHtml += `<div class="bj-tech-item"><span class="bj-tech-label">Chunk Size:</span> ${job.processing.chunk_size?.toLocaleString() || '—'} records</div>`;
                techHtml += `<div class="bj-tech-item"><span class="bj-tech-label">Max Concurrency:</span> ${job.processing.max_concurrency || '—'}</div>`;
            }
            if (job.retry_policy) {
                if (job.retry_policy.connectivity) {
                    techHtml += `<div class="bj-tech-item"><span class="bj-tech-label">Retry (Connectivity):</span> ${job.retry_policy.connectivity.attempts} attempts @ ${job.retry_policy.connectivity.frequency_seconds}s</div>`;
                }
                if (job.retry_policy.api_calls) {
                    techHtml += `<div class="bj-tech-item"><span class="bj-tech-label">Retry (API Calls):</span> ${job.retry_policy.api_calls.attempts} attempts @ ${job.retry_policy.api_calls.frequency_seconds}s</div>`;
                }
            }
            techHtml += '</div>';
            techContent.innerHTML = techHtml;
            techHeader.addEventListener('click', () => {
                const isHidden = techContent.style.display === 'none';
                techContent.style.display = isHidden ? 'block' : 'none';
                techHeader.querySelector('.bj-collapse-icon').textContent = isHidden ? '▼' : '▶';
            });
            techWrap.appendChild(techHeader);
            techWrap.appendChild(techContent);
            card.appendChild(techWrap);
        }

        // Manual trigger instructions (collapsible)
        if (job.manual_trigger) {
            const manualWrap = document.createElement('div');
            manualWrap.className = 'bj-manual-trigger bj-collapsible';
            const manualHeader = document.createElement('button');
            manualHeader.className = 'bj-collapsible-header bj-manual-collapsible-header';
            manualHeader.innerHTML = `<span class="bj-collapse-icon">▶</span> 🔧 Manual Trigger Instructions`;
            manualHeader.type = 'button';
            const manualContent = document.createElement('div');
            manualContent.className = 'bj-collapsible-content';
            manualContent.style.display = 'none';
            let manualHtml = `<div class="bj-manual-platform"><strong>Platform:</strong> ${job.manual_trigger.platform}</div>`;
            if (job.manual_trigger.steps && job.manual_trigger.steps.length) {
                manualHtml += '<ol class="bj-manual-steps">';
                job.manual_trigger.steps.forEach(step => {
                    manualHtml += `<li>${step}</li>`;
                });
                manualHtml += '</ol>';
            }
            if (job.manual_trigger.immediate_execution) {
                manualHtml += `<div class="bj-manual-note"><strong>⚡ Immediate Execution:</strong> ${job.manual_trigger.immediate_execution}</div>`;
            }
            if (job.manual_trigger.verification) {
                manualHtml += `<div class="bj-manual-verify"><strong>✅ Verify Job Status:</strong> Check the <em>${job.manual_trigger.verification.table}</em> table for job name <code>${job.manual_trigger.verification.job_name}</code>. Confirm status transitions: ${job.manual_trigger.verification.status_flow.join(' → ')}</div>`;
            }
            manualContent.innerHTML = manualHtml;
            manualHeader.addEventListener('click', () => {
                const isHidden = manualContent.style.display === 'none';
                manualContent.style.display = isHidden ? 'block' : 'none';
                manualHeader.querySelector('.bj-collapse-icon').textContent = isHidden ? '▼' : '▶';
            });
            manualWrap.appendChild(manualHeader);
            manualWrap.appendChild(manualContent);
            card.appendChild(manualWrap);
        }

        // Trigger pills
        const pillsWrap = document.createElement('div');
        pillsWrap.className = 'link-group';
        pillsWrap.style.marginTop = '0.4rem';

        const curlBlock = document.createElement('div');
        curlBlock.className = 'curl-block';
        const curlPre = document.createElement('pre');
        curlPre.style.margin = '0';
        const copyBtn = document.createElement('button');
        copyBtn.className = 'curl-copy';
        copyBtn.textContent = 'Copy';
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(curlPre.textContent).then(() => {
                copyBtn.textContent = 'Copied!';
                setTimeout(() => copyBtn.textContent = 'Copy', 1500);
            });
        });
        curlBlock.appendChild(copyBtn);
        curlBlock.appendChild(curlPre);

        job.triggers.forEach(t => {
            const pill = document.createElement('button');
            pill.className = 'job-pill';
            const badge = document.createElement('span');
            badge.className = `api-method ${t.method}`;
            badge.textContent = t.method;
            pill.appendChild(badge);
            pill.appendChild(document.createTextNode(' ' + (t.name || t.path)));

            pill.addEventListener('click', () => {
                if (pill.classList.contains('active')) {
                    pill.classList.remove('active');
                    curlBlock.classList.remove('visible');
                    return;
                }
                pillsWrap.querySelectorAll('.job-pill').forEach(p => p.classList.remove('active'));
                pill.classList.add('active');
                const batchBase = ENVS[getActiveJobEnv()].batchBase || '';
                curlPre.dataset.bjMethod = t.method;
                curlPre.dataset.bjPath = t.path;
                curlPre.textContent = `curl -X ${t.method} \\\n  "${batchBase}${t.path}" \\\n  -H "Authorization: Bearer {access_token}" \\\n  -H "Content-Type: application/json"`;
                curlBlock.classList.add('visible');
            });

            pillsWrap.appendChild(pill);
        });

        card.appendChild(pillsWrap);
        card.appendChild(curlBlock);
        return card;
    }

    function buildJobHistoryPanel(jobs) {
        const panel = document.createElement('div');

        const historyFilter = document.createElement('div');
        historyFilter.style.cssText = 'display:flex;gap:1rem;align-items:center;margin-bottom:0.75rem;flex-wrap:wrap;';
        historyFilter.innerHTML = `
            <div style="display:flex;align-items:center;gap:0.4rem;">
                <label style="font-weight:600;font-size:0.82rem;color:#555;">Job:</label>
                <select id="history-job-filter" style="padding:0.3rem 0.5rem;border:1px solid #ccc;border-radius:4px;font-size:0.82rem;min-width:200px;">
                    <option value="">All Jobs</option>
                    ${jobs.map(j => `<option value="${j.name}">${j.name}</option>`).join('')}
                </select>
            </div>
            <div style="display:flex;align-items:center;gap:0.4rem;">
                <label style="font-weight:600;font-size:0.82rem;color:#555;">Status:</label>
                <select id="history-status-filter" style="padding:0.3rem 0.5rem;border:1px solid #ccc;border-radius:4px;font-size:0.82rem;">
                    <option value="">All</option>
                    <option value="success">Success</option>
                    <option value="failed">Failed</option>
                    <option value="running">Running</option>
                </select>
            </div>
            <div style="display:flex;align-items:center;gap:0.4rem;">
                <label style="font-weight:600;font-size:0.82rem;color:#555;">Date:</label>
                <input type="date" id="history-date-filter" style="padding:0.3rem 0.5rem;border:1px solid #ccc;border-radius:4px;font-size:0.82rem;">
            </div>
            <button id="history-refresh-btn" style="background:#0a66c2;color:#fff;border:none;border-radius:5px;padding:0.35rem 0.85rem;font-size:0.82rem;font-weight:600;cursor:pointer;">🔄 Refresh</button>
        `;
        panel.appendChild(historyFilter);

        const historyTable = document.createElement('table');
        historyTable.className = 'cred-table job-history-table';
        const historyThead = document.createElement('thead');
        historyThead.innerHTML = `
            <tr>
                <th>Job Name</th>
                <th>Scheduler Type</th>
                <th>Scheduled Time</th>
                <th>Actual Start</th>
                <th>Actual End</th>
                <th>Duration</th>
                <th>Status</th>
                <th>Records</th>
                <th>Notes</th>
            </tr>
        `;
        historyTable.appendChild(historyThead);
        const historyTbody = document.createElement('tbody');
        historyTable.appendChild(historyTbody);
        panel.appendChild(historyTable);

        const sampleHistory = [
            { job: 'Daily Delta (CCA + Non CCA)', schedulerType: 'UC4', scheduledTime: '2024-01-15 06:00', actualStart: '2024-01-15 06:00:12', actualEnd: '2024-01-15 06:42:18', status: 'success', records: 1245 },
            { job: 'Batch Bulk', schedulerType: 'UC4', scheduledTime: '2024-01-15 02:00', actualStart: '2024-01-15 02:00:05', actualEnd: '2024-01-15 03:52:33', status: 'success', records: 8923 },
            { job: 'CAISO Registration', schedulerType: 'UC4', scheduledTime: '2024-01-15 09:00', actualStart: '2024-01-15 09:00:18', actualEnd: '2024-01-15 09:28:45', status: 'success', records: 156 },
            { job: 'CAISO DR Rule 24 Retrieve Locations', schedulerType: 'Anypoint Scheduler', scheduledTime: '2024-01-15 14:30', actualStart: '2024-01-15 14:30:02', actualEnd: '2024-01-15 14:58:45', status: 'success', records: 6000 },
            { job: 'CCB Char Batch', schedulerType: 'UC4', scheduledTime: '2024-01-15 03:00', actualStart: '2024-01-15 03:00:02', actualEnd: '2024-01-15 03:45:12', status: 'failed', records: 0, notes: 'Connection timeout to CCB' },
            { job: 'Req2Interval', schedulerType: 'UC4', scheduledTime: '2024-01-15 00:30', actualStart: '2024-01-15 00:30:08', actualEnd: null, status: 'running', records: 45023 },
            { job: 'Customer Auth Report', schedulerType: 'UC4', scheduledTime: '2024-01-15 07:30', actualStart: '2024-01-15 07:30:05', actualEnd: '2024-01-15 07:58:22', status: 'success', records: 892 },
        ];

        function formatDuration(ms) {
            const totalSec = Math.floor(ms / 1000);
            const hours = Math.floor(totalSec / 3600);
            const mins = Math.floor((totalSec % 3600) / 60);
            const secs = totalSec % 60;
            if (hours > 0) return `${hours}h ${mins}m ${secs}s`;
            if (mins > 0) return `${mins}m ${secs}s`;
            return `${secs}s`;
        }

        function renderJobHistory(data) {
            historyTbody.innerHTML = data.map(row => {
                const duration = row.actualStart && row.actualEnd
                    ? formatDuration(new Date(row.actualEnd) - new Date(row.actualStart))
                    : row.status === 'running' ? 'In progress...' : '—';
                const statusClass = row.status;
                const schedulerType = row.schedulerType || 'UC4';
                const schedulerBadgeClass = schedulerType === 'Anypoint Scheduler' ? 'anypoint' : (schedulerType === 'UC4' ? 'uc4' : 'rest');
                return `
                    <tr>
                        <td><strong>${row.job}</strong></td>
                        <td><span class="bj-scheduler-badge ${schedulerBadgeClass}">${schedulerType}</span></td>
                        <td>${row.scheduledTime}</td>
                        <td>${row.actualStart || '—'}</td>
                        <td>${row.actualEnd || '—'}</td>
                        <td>${duration}</td>
                        <td><span class="job-status-badge ${statusClass}">${row.status.toUpperCase()}</span></td>
                        <td style="text-align:right;">${row.records?.toLocaleString() || '—'}</td>
                        <td style="color:#666;font-size:0.78rem;">${row.notes || ''}</td>
                    </tr>
                `;
            }).join('');
        }

        const jobFilter = historyFilter.querySelector('#history-job-filter');
        const statusFilter = historyFilter.querySelector('#history-status-filter');
        const dateFilter = historyFilter.querySelector('#history-date-filter');
        const refreshBtn = historyFilter.querySelector('#history-refresh-btn');

        function applyFilters() {
            let filtered = [...sampleHistory];
            const jobVal = jobFilter.value;
            const statusVal = statusFilter.value;
            const dateVal = dateFilter.value;
            if (jobVal) filtered = filtered.filter(r => r.job === jobVal);
            if (statusVal) filtered = filtered.filter(r => r.status === statusVal);
            if (dateVal) filtered = filtered.filter(r => r.scheduledTime.startsWith(dateVal));
            renderJobHistory(filtered);
        }

        jobFilter.addEventListener('change', applyFilters);
        statusFilter.addEventListener('change', applyFilters);
        dateFilter.addEventListener('change', applyFilters);
        refreshBtn.addEventListener('click', () => {
            refreshBtn.disabled = true;
            refreshBtn.textContent = '⏳ Loading...';
            setTimeout(() => {
                renderJobHistory(sampleHistory);
                refreshBtn.disabled = false;
                refreshBtn.textContent = '🔄 Refresh';
            }, 500);
        });

        renderJobHistory(sampleHistory);

        return panel;
    }

    window.SMD2_BatchJobsTab = {
        render: renderBatchJobsTab
    };

})(window);
