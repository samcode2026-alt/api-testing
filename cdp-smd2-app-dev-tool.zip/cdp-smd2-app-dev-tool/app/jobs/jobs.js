// Batch job definitions.
// Each job has a name, description, schedule, and one or more trigger endpoints.
// App names in trigger paths correspond to entries in apilist.txt.
// auth_type: "basic" | "jwt_bearer" - determines authentication method
// cert_env_var: environment variable name for JWT certificate (when auth_type is "jwt_bearer")
window.SMD2_JOBS = [
    {
        type: "Authorization & Delta",
        name: "Daily Delta (CCA + Non CCA)",
        desc: "Generates the usage and billing XML file for CCA and Non-CCA vendors based on their commodity types, uploads it to S3, and notifies the vendor.",
        summary: "Processes daily authorization delta for CCA and Non-CCA vendors, generates XML files, uploads to S3.",
        auth_type: "basic",
        scheduler_type: "UC4",
        schedule: {
            days: ["Mon", "Tue", "Wed", "Thu", "Fri"],
            startTime: "06:00",
            expectedRuntime: "45 min",
            queue: "smd2-auth-delta-queue"
        },
        triggers: [
            { method: "POST", name: "Daily Delta", path: "/cdp-smd2-auth-processor-app/api/auth-sa-daily" },
            { method: "POST", name: "TOT Codes", path: "/cdp-smd2-auth-processor-app/api/tot-codes" },
            { method: "POST", name: "Delta CCA", path: "/cdp-smd2-auth-processor-app/api/authorizations/delta/cca" },
            { method: "POST", name: "Delta Non-CCA", path: "/cdp-smd2-auth-processor-app/api/authorizations/delta/non-cca" }
        ]
    },
    {
        type: "Authorization & Delta",
        name: "Offline Authorizations Cancel",
        desc: "Cancels Rule 24 subscriptions as per the data from the CISR intake process.",
        summary: "Cancels Rule 24 subscriptions based on CISR intake data.",
        auth_type: "basic",
        scheduler_type: "UC4",
        schedule: {
            days: ["Mon", "Tue", "Wed", "Thu", "Fri"],
            startTime: "07:00",
            expectedRuntime: "15 min",
            queue: "smd2-cisr-cancel-queue"
        },
        triggers: [
            { method: "DELETE", name: "Cancel CISR Authorizations", path: "/cdp-smd2-cisr-processor-app/api/cisr-authorizations" }
        ]
    },
    {
        type: "Authorization & Delta",
        name: "Add / Delete",
        desc: "Handles add and delete operations for SMD2 subscriptions.",
        summary: "Processes add/delete operations for SMD2 subscriptions.",
        auth_type: "basic",
        scheduler_type: "UC4",
        schedule: {
            days: ["Mon", "Tue", "Wed", "Thu", "Fri"],
            startTime: "08:00",
            expectedRuntime: "30 min",
            queue: "smd2-add-delete-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger Add/Delete", path: "/cdp-smd2-add-delete-app/api/trigger" }
        ]
    },
    {
        type: "Batch Data",
        name: "Batch Bulk",
        desc: "Generates bulk usage data files for all active subscriptions.",
        summary: "Generates bulk usage data files for all active subscriptions and uploads to S3.",
        auth_type: "jwt_bearer",
        cert_env_var: "SMD2_JWT_CERT",
        scheduler_type: "UC4",
        schedule: {
            days: ["Daily"],
            startTime: "02:00",
            expectedRuntime: "2 hrs",
            queue: "smd2-batch-bulk-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger Bulk", path: "/cdp-smd2-batch-bulk-app/api/trigger" }
        ]
    },
    {
        type: "Batch Data",
        name: "Batch Bulk Customer Info",
        desc: "Generates bulk customer info data files for active subscriptions.",
        summary: "Generates bulk customer information files for active subscriptions.",
        auth_type: "jwt_bearer",
        cert_env_var: "SMD2_JWT_CERT",
        scheduler_type: "UC4",
        schedule: {
            days: ["Daily"],
            startTime: "04:00",
            expectedRuntime: "1 hr",
            queue: "smd2-batch-bulk-custinfo-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger Bulk Customer Info", path: "/cdp-smd2-batch-bulk-customer-info-app/api/trigger" }
        ]
    },
    {
        type: "Batch Data",
        name: "Batch Subscription",
        desc: "Processes subscription batch operations.",
        summary: "Processes batch subscription operations for all active subscriptions.",
        auth_type: "jwt_bearer",
        cert_env_var: "SMD2_JWT_CERT",
        scheduler_type: "UC4",
        schedule: {
            days: ["Daily"],
            startTime: "05:00",
            expectedRuntime: "45 min",
            queue: "smd2-batch-subscription-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger Subscription Batch", path: "/cdp-smd2-batch-subscription-app/api/trigger" }
        ]
    },
    {
        type: "CAISO",
        name: "CAISO DR Rule 24 Retrieve Locations",
        desc: "Retrieves CAISO DR Rule 24 location data and stores in S3 for downstream processing via Rule24 and CAISO SAPIs.",
        summary: "Retrieves CAISO DR Rule 24 locations, processes in chunks of 6000 records, and uploads to AWS S3.",
        auth_type: "",
        cert_env_var: "",
        scheduler_type: "Anypoint Scheduler",
        status: "COMPLETED",
        schedule: {
            days: ["Daily"],
            startTime: "06:00",
            timezone: "America/Los_Angeles",
            cron: "0 00 06 * * ?",
            expectedRuntime: "30 min",
            queue: ""
        },
        application: {
            name: "cdp-smd2-caiso-retrieve-app",
            job_name: "EI_DRRULE24_CAISODRRSRETRIEVELOCATIONS",
            downstream_apis: ["cdp-smd2-rule24-sapi", "cdp-smd2-caiso-sapi"]
        },
        messaging: {
            type: "Anypoint MQ",
            queue: "retrieveLocation"
        },
        storage: {
            type: "AWS S3",
            folder: "CAISO/RetrieveLocations/RetrieveLocations"
        },
        processing: {
            chunk_size: 6000,
            max_concurrency: 1
        },
        retry_policy: {
            connectivity: { attempts: 3, frequency_seconds: 30 },
            api_calls: { attempts: 3, frequency_seconds: 2 }
        },
        manual_trigger: {
            platform: "Anypoint Platform Runtime Manager",
            steps: [
                "Log into Anypoint Platform Runtime Manager",
                "Navigate to the environment where the application is deployed",
                "Locate cdp-smd2-caiso-retrieve-app",
                "Stop the application",
                "Wait for the application to fully stop (status = Undeployed/Stopped)",
                "Start the application",
                "The scheduler will trigger at the next configured CRON time (2:30 PM PST)"
            ],
            immediate_execution: "For immediate execution outside the scheduled window, coordinate with the development team to temporarily modify the CRON expression via Runtime Manager properties or redeploy with an updated schedule",
            verification: {
                table: "Job Completion",
                job_name: "EI_DRRULE24_CAISODRRSRETRIEVELOCATIONS",
                status_flow: ["STARTED", "COMPLETED"]
            }
        },
        triggers: [
            
        ]
    },
    {
        type: "CAISO",
        name: "CAISO DR Rule 24 Review Locations",
        
        desc: "Reviews CAISO submissions before final submit.",
        summary: "Reviews CAISO submissions for accuracy before final submission.",
        auth_type: "",
        cert_env_var: "",
        scheduler_type: "Anypoint Scheduler",
        schedule: {
            days: ["Daily"],
            startTime: "11:00",
            expectedRuntime: "15 min",
            cron: "0 00 11 * * ?",
            queue: "smd2-caiso-review-queue"
        },
        application: {
            name: "cdp-smd2-caiso-review-app",
            job_name: "EI_DRRULE24_CAISODRRSREVIEWLOCATIONS",
            downstream_apis: ["cdp-smd2-rule24-sapi", "cdp-smd2-caiso-sapi"]
        },
        triggers: [
            
        ]
    },
    {
        type: "CAISO",
        name: "CAISO DR Rule 24 Submit Locations",
        desc: "Submits reviewed CAISO data for final processing.",
        summary: "Submits reviewed CAISO data for final processing.",
        auth_type: "",
        cert_env_var: "",
        scheduler_type: "Anypoint Scheduler",
        schedule: {
            days: ["Daily"],
            startTime: "12:00",
            expectedRuntime: "20 min",
            cron: "0 00 12 * * ?",
            queue: "smd2-caiso-submit-queue"
        },
        application: {
            name: "cdp-smd2-caiso-submit-app",
            job_name: "EI_DRRULE24_CAISODRRSSUBMITLOCATIONS",
            downstream_apis: ["cdp-smd2-rule24-sapi", "cdp-smd2-caiso-sapi"]
        },
        triggers: [
            
        ]
    },
    {
        type: "CAISO",
        name: "CAISO DR Rule 24 Retrieve Registrations",
        desc: "Retrieves data from CAISO for processed subscriptions.",
        summary: "Retrieves processed data from CAISO for completed registrations.",
        auth_type: "",
        cert_env_var: "",
        scheduler_type: "Anypoint Scheduler",
        schedule: {
            days: ["Daily"],
            startTime: "14:30",
            expectedRuntime: "25 min",
            cron: "0 30 14 * * ?",
            queue: "smd2-caiso-retrieve-queue"
        },
        application: {
            name: "cdp-smd2-caiso-submit-app",
            job_name: "EI_DRRULE24_CAISODRRSRETRIEVEREGISTRATIONS",
            downstream_apis: ["cdp-smd2-rule24-sapi", "cdp-smd2-caiso-sapi"]
        },
        triggers: [
            
        ]
    },
    {
        type: "CAISO",
        name: "CAISO DR Rule 24 Batch Status",
        desc: "Retrieves and updates CAISO batch job statuses.",
        summary: "Checks CAISO batch job statuses and updates tracking database.",
        auth_type: "",
        cert_env_var: "",
        scheduler_type: "Anypoint Scheduler",
        schedule: {
            days: ["Daily"],
            startTime: "17:00",
            expectedRuntime: "20 min",
            cron: "0 00 17 * * ?",
            queue: "smd2-caiso-status-queue"
        },
        triggers: [
            
        ]
    },
    {
        type: "CCB",
        name: "CCB Char Batch",
        desc: "Processes CCB characteristics batch updates.",
        summary: "Updates CCB characteristics for subscriptions in batch mode.",
        auth_type: "basic",
        scheduler_type: "UC4",
        schedule: {
            days: ["Daily"],
            startTime: "03:00",
            expectedRuntime: "1 hr",
            queue: "smd2-ccb-char-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger CCB Char", path: "/cdp-smd2-ccb-char-batch-app/api/trigger" }
        ]
    },
    {
        type: "Migration",
        name: "Clients Migration",
        desc: "Onetime job to migrate the clients.",
        summary: "One-time migration job to migrate clients from legacy system.",
        auth_type: "",
        scheduler_type: "Anypoint Scheduler",
        schedule: {
            days: ["Onetme"],
            startTime: "01:00",
            expectedRuntime: "2 hrs",
            queue: "smd2-migration-queue"
        },
        triggers: [
            
        ]
    },
    {
        type: "Reports",
        name: "Customer Auth Report",
        desc: "Generates customer authorization reports.",
        summary: "Generates authorization reports for customers.",
        auth_type: "basic",
        scheduler_type: "UC4",
        schedule: {
            days: ["Mon", "Wed", "Fri"],
            startTime: "07:30",
            expectedRuntime: "30 min",
            queue: "smd2-cust-auth-report-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger Report", path: "/cdp-smd2-cust-auth-report-app/api/trigger" }
        ]
    },
    {
        type: "Demand Response",
        name: "DR Program Info",
        desc: "Syncs demand response program info data.",
        summary: "Synchronizes demand response program information from source systems.",
        auth_type: "jwt_bearer",
        cert_env_var: "SMD2_DR_CERT",
        scheduler_type: "UC4",
        schedule: {
            days: ["Tue", "Thu"],
            startTime: "14:00",
            expectedRuntime: "20 min",
            queue: "smd2-dr-prg-info-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger DR Prg Info", path: "/cdp-smd2-dr-prg-info-app/api/trigger" }
        ]
    },
    {
        type: "Demand Response",
        name: "DR Program",
        desc: "Processes demand response program enrollment and updates.",
        summary: "Processes DR program enrollments and updates participant records.",
        auth_type: "jwt_bearer",
        cert_env_var: "SMD2_DR_CERT",
        scheduler_type: "UC4",
        schedule: {
            days: ["Tue", "Thu"],
            startTime: "15:00",
            expectedRuntime: "25 min",
            queue: "Q.SMD2.DRP.PRG.INFO.ENV"
        },
        triggers: [
            { method: "POST", name: "Trigger DR Program", path: "/cdp-smd2-dr-program-app/api/trigger" }
        ]
    },
    {
        type: "Data Processing",
        name: "Req2Interval",
        desc: "Converts request data to interval block format.",
        summary: "Converts raw request data to standardized interval block format.",
        auth_type: "basic",
        scheduler_type: "UC4",
        schedule: {
            days: ["Daily"],
            startTime: "00:30",
            expectedRuntime: "3 hrs",
            queue: "smd2-req2interval-queue"
        },
        triggers: [
            { method: "POST", name: "Trigger Req2Interval", path: "/cdp-smd2-req2interval-app/api/trigger" }
        ]
    }
];

// Batch Jobs Display Configuration
// Global settings for batch job display
window.SMD2_BATCH_JOBS_CONFIG = {
    // Time format: "12h" for 12-hour (AM/PM) or "24h" for 24-hour format
    timeFormat: "12h"
};

// Authentication configuration for batch jobs
// This can be overridden via environment variables
window.SMD2_JOB_AUTH_CONFIG = {
    // Basic Auth credentials (per environment)
    basic: {
        env_var_user: "SMD2_BATCH_USER",
        env_var_pass: "SMD2_BATCH_PASS"
    },
    // JWT Bearer Token configuration
    jwt_bearer: {
        // Certificate environment variables per cert type
        certs: {
            "SMD2_JWT_CERT": { desc: "Default JWT signing certificate", env_var: "SMD2_JWT_CERT_PATH" },
            "SMD2_CAISO_CERT": { desc: "CAISO integration certificate", env_var: "SMD2_CAISO_CERT_PATH" },
            "SMD2_DR_CERT": { desc: "Demand Response certificate", env_var: "SMD2_DR_CERT_PATH" }
        },
        token_url_env_var: "SMD2_JWT_TOKEN_URL",
        client_id_env_var: "SMD2_JWT_CLIENT_ID"
    }
};
