// OAuth / DataCustodian API definitions parsed from apilist.txt.
window.SMD2_OAUTH_APIS = [
    {
        group: "🔐 OAuth APIs",
        apis: [
            {
                status: "TEST", method: "GET", path: "/test/oauth/v2/authorize", sla: 4,
                desc: "Request test authorization code",
                paramStyle: "query",
                params: [
                    { key: "client_id", source: "client_id" },
                    { key: "redirect_uri", source: "redirect_uri" },
                    { key: "response_type", value: "code" },
                    { key: "state", value: "landingpage" }
                ]
            },
            {
                status: "TEST", method: "POST", path: "/test/oauth/v2/token", sla: 4,
                desc: "Get test access token",
                paramStyle: "form",
                params: [
                    { key: "grant_type", value: "authorization_code" },
                    { key: "code", value: "{authorization_code}" },
                    { key: "redirect_uri", source: "redirect_uri" },
                    { key: "client_id", source: "client_id" },
                    { key: "client_secret", source: "client_secret" }
                ]
            },
            {
                status: "TEST", method: "GET", path: "/oauth/v2/authorize", sla: 4,
                desc: "Request live authorization code",
                paramStyle: "query",
                params: [
                    { key: "client_id", source: "client_id" },
                    { key: "redirect_uri", source: "redirect_uri" },
                    { key: "response_type", value: "code" },
                    { key: "state", value: "landingpage" }
                ]
            },
            {
                status: "TEST", method: "POST", path: "/oauth/v2/token", sla: 4,
                desc: "Request or refresh live access token",
                paramStyle: "form",
                params: [
                    { key: "grant_type", value: "authorization_code" },
                    { key: "code", value: "{authorization_code}" },
                    { key: "redirect_uri", source: "redirect_uri" },
                    { key: "client_id", source: "client_id" },
                    { key: "client_secret", source: "client_secret" }
                ]
            }
        ]
    }
];

// GreenButtonConnect API definitions parsed from apilist.txt.
// Each entry: { method, path, desc, status, basePath?, clientTypes? }
// basePath (if set) is prepended to `path` when building the full URL.
// clientTypes: array of client types that can use this API (SU=Standard User, CA=CCA, SA=Service Account)
// If clientTypes is not specified, the API is available to all client types.
window.SMD2_APIS = [
    {
        group: "📋 Application Information API",
        apis: [
            { status: "QA/UAT", method: "GET", path: "/ApplicationInformation/{ApplicationInformationID}", sla: 1, auth_token: "registration_access_token", desc: "Get application information", clientTypes: ["SU", "CA", "SA"] }
        ]
    },
    {
        group: "🧪 Test APIs",
        apis: [
            { status: "QA/UAT", method: "GET", path: "/DownloadSampleData", sla: 1, auth_token: "client_access_token", desc: "Connectivity test with sample data", clientTypes: ["SU", "CA", "SA"] },
            { status: "TEST", method: "GET", path: "/ReadServiceStatus", sla: 1, auth_token: "client_access_token", desc: "Check server status", clientTypes: ["SU", "CA", "SA"] },
            { status: "QA/UAT", method: "GET", path: "/LocalTimeParameters", sla: 1, auth_token: "access_token", desc: "Retrieve local time details", clientTypes: ["SU"] },
            { status: "QA/UAT", method: "GET", path: "/LocalTimeParameters/{LocalTimeParameterID}", sla: 1, auth_token: "access_token", desc: "Retrieve local time details for ID", clientTypes: ["SU"] }
        ]
    },
    {
        group: "🔑 Authorization APIs",
        apis: [
            { status: "QA/UAT", method: "GET", path: "/Authorization", sla: 4, auth_token: "client_access_token", desc: "Retrieve all authorizations including application information and bulk id", clientTypes: ["SU", "CA", "SA"] },
            { status: "QA/UAT", method: "GET", path: "/Authorization/{AuthorizationID}", sla: 4, auth_token: "client_access_token", desc: "Retrieve specific authorization", clientTypes: ["SU", "CA", "SA"] },
            { status: "QA/UAT", method: "DELETE", path: "/Authorization/{AuthorizationID}", sla: 4, auth_token: "client_access_token", desc: "Revoke authorization", clientTypes: ["SU", "SA"] }
        ]
    },
    {
        group: "📍 Usage Point APIs",
        apis: [
            { status: "TEST", method: "GET", path: "/Subscription/{SubscriptionID}/UsagePoint", sla: 4, auth_token: "access_token", desc: "All usage points", clientTypes: ["SU"] },
            { status: "QA/UAT", method: "GET", path: "/Subscription/{SubscriptionID}/UsagePoint/{UsagePointID}", sla: 4, auth_token: "access_token", desc: "Single usage point", clientTypes: ["SU"] }
        ]
    },
    {
        group: "💡 Usage & Billing – Subscription & Batch",
        apis: [
            { status: "QA/UAT", method: "GET", path: "/Batch/Subscription/{SubscriptionID}", type:"Async"  , sla: 4, auth_token: "access_token", desc: "All usage points usage+billing", clientTypes: ["SU"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" },
                    { key: "updated-min", value: "", type: "datez" },
                    { key: "updated-max", value: "", type: "datez" }
                ]
            },
            { status: "QA/UAT", method: "GET", path: "/Batch/Subscription/{SubscriptionID}/UsagePoint/{UsagePointID}", sla: 4, auth_token: "access_token", desc: "Single usage point full feed", clientTypes: ["SU"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" },
                    { key: "updated-min", value: "", type: "datez" },
                    { key: "updated-max", value: "", type: "datez" }
                ]
            },
            { status: "QA/UAT", method: "GET", path: "/Batch/Custom/Subscription/{SubscriptionID}", sla: 4, auth_token: "client_access_token", desc: "Retrieves energy usage data for a custom (offline) subscription SU/PRIM/SEC", clientTypes: ["SU", "SA"] }
        ]
    },
    {
        group: "📊 Reading Type APIs",
        apis: [
            { status: "QA/UAT", method: "GET", path: "/ReadingType", sla: 4, auth_token: "access_token", desc: "All reading types", clientTypes: ["SU"] },
            { status: "QA/UAT", method: "GET", path: "/ReadingType/{ReadingTypeID}", sla: 4, auth_token: "access_token", desc: "Single reading type", clientTypes: ["SU"] }
        ]
    },
    {
        group: "💵 Billing APIs (UsageSummary)",
        basePath: "/Subscription/{SubscriptionID}/UsagePoint/{UsagePointID}",
        apis: [
            {
                status: "QA/UAT", method: "GET", path: "/UsageSummary", sla: 4, auth_token: "access_token", desc: "All summaries", clientTypes: ["SU"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" },
                    { key: "updated-min", value: "", type: "datez" },
                    { key: "updated-max", value: "", type: "datez" }
                ]
            },
            {
                status: "QA/UAT", method: "GET", path: "/UsageSummary/{UsageSummaryID}", sla: 4, auth_token: "access_token", desc: "Specific summary", clientTypes: ["SU"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" },
                    { key: "updated-min", value: "", type: "datez" },
                    { key: "updated-max", value: "", type: "datez" }
                ]
            }
        ]
    },
    {
        group: "⏱️ Usage APIs (Meter Reading & Interval Block)",
        basePath: "/Subscription/{SubscriptionID}/UsagePoint/{UsagePointID}",
        apis: [
            { status: "NOT STARTED", method: "GET", path: "/MeterReading", auth_token: "access_token", desc: "All meter readings", clientTypes: ["SU"] },
            { status: "NOT STARTED", method: "GET", path: "/MeterReading/{MeterReadingID}", auth_token: "access_token", desc: "Single reading", clientTypes: ["SU"] },
            { status: "NOT STARTED", method: "GET", path: "/MeterReading/{MeterReadingID}/IntervalBlock", auth_token: "access_token", desc: "Interval data", clientTypes: ["SU"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" },
                    { key: "updated-min", value: "", type: "datez" },
                    { key: "updated-max", value: "", type: "datez" }
                ]
            },
            { status: "NOT STARTED", method: "GET", path: "/MeterReading/{MeterReadingID}/IntervalBlock/{IntervalBlockID}", auth_token: "access_token", desc: "Single day interval block", clientTypes: ["SU"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" },
                    { key: "updated-min", value: "", type: "datez" },
                    { key: "updated-max", value: "", type: "datez" }
                ]
            }
        ]
    },
    {
        group: "📦 Bulk Usage & Billing",
        apis: [
            { status: "QA/UAT", method: "GET", type:"Async", path: "/Batch/Bulk/{BulkID}", sla: 4, auth_token: "client_access_token", desc: "All usage + billing across all customers authorized", clientTypes: ["SU", "SA","CA"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" }
                ]}
        ]
    },
    {
        group: "👤 Customer Information APIs",
        apis: [
            { status: "QA/UAT", method: "GET", type:"Async", path: "/Batch/RetailCustomer/{RetailCustomerID}", sla: 4, auth_token: "access_token", desc: "Retrieve basic account & customer info", clientTypes: ["SU"] },
            { status: "QA/UAT", method: "GET", type:"Async", path: "/Batch/BulkRetailCustomerInfo/{BulkID}", sla: 4, auth_token: "client_access_token", desc: "Customer info across all authorizations", clientTypes: ["SU", "SA","CA"] },
            { status: "NOT STARTED", method: "GET", path: "/Batch/Custom/RetailCustomer/{RetailCustomerID}", sla: 4, auth_token: "client_access_token", desc: "Retrieve customer information for a specific custom offline subscription", clientTypes: ["SU", "SA"] },
            { status: "NOT STARTED", method: "GET", path: "/Batch/Custom/RetailDRPrgInfo/{RetailCustomerID}", sla: 4, auth_token: "client_access_token", desc: "Retrieve Demand Response (DR) Program information for a specific custom offline subscription", clientTypes: ["SU", "SA"] }
        ]
    },
    {
        group: "⚡ Demand Response Enrollment APIs",
        apis: [
            { status: "NOT STARTED", method: "GET", path: "/Batch/RetailDRPrgInfo/{RetailCustomerID}", sla: 4, auth_token: "access_token", desc: "DR program enrollment info", clientTypes: ["SU"] },
            { status: "NOT STARTED", method: "GET", type:"Async", path: "/Batch/BulkRetailDRPrgInfo/{BulkID}", sla: 4, auth_token: "client_access_token", desc: "All DR enrollment for all authorizations", clientTypes: ["SU", "SA"] }
        ]
    },
    {
        group: "🏛️ CCA (Community Choice Aggregators) APIs",
        apis: [
            { status: "QA/UAT", method: "GET", path: "/customCCA/Batch/Subscription/UsagePoint/{UsagePointID}", sla: 4, auth_token: "client_access_token", desc: "Retrieve energy usage data for a specific CCA usage point", clientTypes: ["CA"],
                params: [
                    { key: "published-min", value: "2024-09-30T17:00:00.00Z", type: "datez" },
                    { key: "published-max", value: "2026-09-30T17:00:00.00Z", type: "datez" },
                    { key: "updated-min", value: "", type: "datez" },
                    { key: "updated-max", value: "", type: "datez" }
                ]},
            { status: "NOT STARTED", method: "GET", path: "/customCCA/Batch/RetailCustomer/UsagePoint/{UsagePointID}", sla: 4, auth_token: "client_access_token", desc: "Retrieve customer information for a specific CCA usage point", clientTypes: ["CA"]
            }
        ]
    }
];
