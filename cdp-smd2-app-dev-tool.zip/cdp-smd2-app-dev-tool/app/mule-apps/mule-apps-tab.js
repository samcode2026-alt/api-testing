// Mule Apps Tab Module
// Renders the Mule Apps tab with health checks and AppConfig sub-tabs
// Requires: SMD2_MULE_APPS, SMD2_APP_LINK_TEMPLATES, SMD2_ENVS globals
// Supports appConfig.tabs.muleApps.enabled and appConfig.tabs.appConfig.enabled for configuration

(function(window) {
    'use strict';

    function renderMuleAppsTab(tabsEl, panelsEl, ENVS, envKeys) {
        const tabGroups = window.SMD2_MULE_APPS || [];
        const templates = window.SMD2_APP_LINK_TEMPLATES || {};
        if (!tabGroups.length) return;

        // Check if Mule Apps tab is enabled in any environment's config
        const anyEnvEnabled = envKeys.some(env => {
            const cfg = ENVS[env]?.appConfig;
            return !cfg || !cfg.tabs || !cfg.tabs.muleApps || cfg.tabs.muleApps.enabled !== false;
        });
        if (!anyEnvEnabled) return;

        function buildUrl(tpl, appName) {
            return (tpl || '').replace(/\{app\}/g, encodeURIComponent(appName));
        }

        function buildAppTable(apps, subPanel) {
            const table = document.createElement('table');
            table.className = 'apps-grid';
            const thead = document.createElement('thead');
            const hr = document.createElement('tr');
            ['App Name', 'Health', 'Exchange', 'Git', 'ELK Logs', 'Monitoring', 'Insights'].forEach(col => {
                const th = document.createElement('th');
                th.textContent = col;
                if (col === 'Health') th.className = 'health-th';
                hr.appendChild(th);
            });
            thead.appendChild(hr);
            table.appendChild(thead);
            const tbody = document.createElement('tbody');
            const linkDefs = [
                { key: 'exchange', cls: 'exchange', icon: '🔗' },
                { key: 'git',      cls: 'git',      icon: '🐙' },
                { key: 'elk',      cls: 'elk',      icon: '📊' },
                { key: 'monitor',  cls: 'monitor',  icon: '📈' },
                { key: 'insights', cls: 'insights', icon: '💡' }
            ];
            apps.forEach(app => {
                const tr = document.createElement('tr');
                tr.className = 'app-row';
                tr.dataset.appName = app.name.toLowerCase();

                const nameTd = document.createElement('td');
                nameTd.className = 'app-name app-name-clickable';
                nameTd.textContent = app.name;
                nameTd.title = 'Click to view APIs';
                nameTd.dataset.appName = app.name;
                nameTd.style.cursor = 'pointer';
                nameTd.addEventListener('click', async () => {
                    const existingExpanded = tr.nextElementSibling;
                    if (existingExpanded && existingExpanded.classList.contains('app-apis-expanded-row')) {
                        existingExpanded.remove();
                        nameTd.classList.remove('expanded');
                        return;
                    }
                    // Remove any other expanded rows in this table
                    tbody.querySelectorAll('.app-apis-expanded-row').forEach(r => r.remove());
                    tbody.querySelectorAll('.app-name-clickable.expanded').forEach(n => n.classList.remove('expanded'));

                    nameTd.classList.add('expanded');
                    const expandedRow = document.createElement('tr');
                    expandedRow.className = 'app-apis-expanded-row';
                    const expandedTd = document.createElement('td');
                    expandedTd.colSpan = 7;
                    expandedTd.innerHTML = '<div class="app-apis-loading">Loading APIs...</div>';
                    expandedRow.appendChild(expandedTd);
                    tr.insertAdjacentElement('afterend', expandedRow);

                    try {
                        const config = await window.SMD2_AppApiManager.loadAppApiConfig(app.name);
                        if (config.apis && config.apis.length > 0) {
                            expandedTd.innerHTML = buildExpandedApiList(app.name, config.apis);
                            attachExpandedApiEvents(expandedTd, app.name, config.apis);
                        } else {
                            expandedTd.innerHTML = `
                                <div class="app-apis-empty">
                                    <span>No APIs configured for this app.</span>
                                    <button class="configure-apis-btn" data-app-name="${app.name}">+ Configure APIs</button>
                                </div>
                            `;
                            expandedTd.querySelector('.configure-apis-btn').addEventListener('click', () => {
                                window.SMD2_AppApiManager.showApiConfigModal(app.name, () => {
                                    nameTd.click(); // Refresh
                                });
                            });
                        }
                    } catch (err) {
                        expandedTd.innerHTML = `<div class="app-apis-error">Failed to load APIs: ${err.message}</div>`;
                    }
                });
                tr.appendChild(nameTd);

                const healthTd = document.createElement('td');
                healthTd.className = 'health-cell';
                const healthBadge = document.createElement('span');
                healthBadge.className = 'health-badge';
                healthBadge.textContent = '—';
                healthBadge.dataset.app = app.name;
                healthTd.appendChild(healthBadge);
                tr.appendChild(healthTd);

                linkDefs.forEach(ld => {
                    const td = document.createElement('td');
                    if (templates[ld.key]) {
                        const a = document.createElement('a');
                        a.className = `app-link ${ld.cls}`;
                        a.href = buildUrl(templates[ld.key], app.name);
                        a.target = '_blank';
                        a.rel = 'noopener';
                        a.textContent = ld.icon;
                        td.appendChild(a);
                    } else {
                        td.textContent = '—';
                    }
                    tr.appendChild(td);
                });
                tbody.appendChild(tr);
            });
            table.appendChild(tbody);
            return table;
        }

        function buildExpandedApiList(appName, apis) {
            return `
                <div class="app-apis-expanded">
                    <div class="app-apis-header">
                        <span class="app-apis-title">📡 APIs for ${appName}</span>
                        <button class="configure-apis-btn-small" data-app-name="${appName}">⚙️ Configure</button>
                    </div>
                    <div class="app-apis-list">
                        ${apis.map((api, idx) => `
                            <div class="app-api-item" data-idx="${idx}">
                                <span class="api-method-badge ${api.method}">${api.method}</span>
                                <span class="app-api-name">${escapeHtml(api.name)}</span>
                                <span class="app-api-endpoint">${escapeHtml(api.endpoint)}</span>
                                <button class="app-api-execute-btn" data-idx="${idx}">▶ Execute</button>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        function attachExpandedApiEvents(container, appName, apis) {
            container.querySelector('.configure-apis-btn-small')?.addEventListener('click', () => {
                window.SMD2_AppApiManager.showApiConfigModal(appName);
            });
            container.querySelectorAll('.app-api-execute-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const idx = parseInt(btn.dataset.idx);
                    window.SMD2_AppApiManager.showApiExecuteModal(appName, apis[idx]);
                });
            });
        }

        function escapeHtml(str) {
            if (str === null || str === undefined) return '';
            return String(str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        }

        const mainBtn = document.createElement('button');
        mainBtn.className = 'tab-button';
        mainBtn.dataset.tab = '__apps__';
        mainBtn.setAttribute('role', 'tab');
        mainBtn.textContent = '🔌 Mule Apps';
        tabsEl.appendChild(mainBtn);

        const panel = document.createElement('section');
        panel.id = '__apps__';
        panel.className = 'tab-panel';
        panel.setAttribute('role', 'tabpanel');

        const subBar = document.createElement('div');
        subBar.style.cssText = 'display:flex;gap:4px;border-bottom:2px solid #ddd;margin:0.75rem 0 0;flex-wrap:wrap;';
        const subPanelsWrap = document.createElement('div');

        tabGroups.forEach((grp, gi) => {
            const subId = `__apps_sub_${gi}__`;

            const subBtn = document.createElement('button');
            subBtn.className = 'tab-button sub-tab-small' + (gi === 0 ? ' active' : '');
            subBtn.dataset.subTab = subId;
            subBtn.textContent = (grp.icon ? grp.icon + ' ' : '') + grp.tab;
            subBar.appendChild(subBtn);

            const subPanel = document.createElement('div');
            subPanel.id = subId;
            subPanel.className = 'cred-panel' + (gi === 0 ? ' active' : '');

            const hcBar = document.createElement('div');
            hcBar.className = 'hc-bar';
            const hcBtn = document.createElement('button');
            hcBtn.className = 'hc-run-btn';
            hcBtn.textContent = '⚡ Run Health Check';
            const hcStatus = document.createElement('span');
            hcStatus.className = 'hc-status-text';
            hcBar.appendChild(hcBtn);
            hcBar.appendChild(hcStatus);
            subPanel.appendChild(hcBar);

            hcBtn.addEventListener('click', async () => {
                const activeEnv = (document.querySelector('#current-env .env-toggle-btn.active') || {}).dataset?.env || envKeys[0];
                const hcBase = ENVS[activeEnv].healthCheckBase || ENVS[activeEnv].batchBase || '';
                const creds = ENVS[activeEnv].healthCheckCreds || {};
                const basicAuth = (creds.username && creds.password)
                    ? `${creds.username}:${creds.password}`
                    : null;
                const badges = subPanel.querySelectorAll('.health-badge');
                if (!badges.length) return;
                hcBtn.disabled = true;
                hcStatus.textContent = `Checking ${badges.length} apps…`;
                badges.forEach(b => { b.className = 'health-badge checking'; b.textContent = '⏳'; });

                const checks = Array.from(badges).map(badge => {
                    const appName = badge.dataset.app;
                    const url = `${hcBase}/${appName}/api/health-check`;
                    return fetch('/api/proxy', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ method: 'GET', url, basicAuth })
                    })
                        .then(r => r.json())
                        .then(data => {
                            if (data.error) {
                                badge.textContent = '❌ Error';
                                badge.className = 'health-badge down';
                            } else if (data.status >= 200 && data.status < 300) {
                                badge.textContent = '✅ UP';
                                badge.className = 'health-badge up';
                            } else {
                                badge.textContent = `❌ ${data.status}`;
                                badge.className = 'health-badge down';
                            }
                        })
                        .catch(err => {
                            badge.textContent = '❌ Error';
                            badge.className = 'health-badge down';
                        });
                });
                await Promise.all(checks);
                hcStatus.textContent = 'Done.';
                hcBtn.disabled = false;
            });

            // Add search bar for APIs
            const searchBar = document.createElement('div');
            searchBar.className = 'app-search-bar';
            searchBar.innerHTML = `
                <label>🔍 Search APIs:</label>
                <input type="text" class="app-search-input" placeholder="Search by API name or endpoint...">
                <button type="button" class="app-search-btn">Search</button>
                <button type="button" class="app-search-clear">✕</button>
                <span class="app-search-status"></span>
            `;
            subPanel.appendChild(searchBar);

            // Search results container
            const searchResultsContainer = document.createElement('div');
            searchResultsContainer.className = 'api-search-results';
            searchResultsContainer.style.display = 'none';
            subPanel.appendChild(searchResultsContainer);

            const searchInput = searchBar.querySelector('.app-search-input');
            const searchBtn = searchBar.querySelector('.app-search-btn');
            const clearBtn = searchBar.querySelector('.app-search-clear');
            const searchStatus = searchBar.querySelector('.app-search-status');

            async function performApiSearch() {
                const query = searchInput.value.trim();
                if (!query) {
                    searchResultsContainer.style.display = 'none';
                    subPanel.querySelectorAll('.apps-grid, .apps-category-header').forEach(el => el.style.display = '');
                    searchStatus.textContent = '';
                    return;
                }

                searchStatus.textContent = 'Searching...';
                searchBtn.disabled = true;

                try {
                    const response = await fetch(`/api/app-apis/search?q=${encodeURIComponent(query)}`);
                    const results = await response.json();

                    if (results.length === 0) {
                        searchResultsContainer.innerHTML = '<div class="api-search-empty">No APIs found matching your search.</div>';
                    } else {
                        searchResultsContainer.innerHTML = `
                            <div class="api-search-header">
                                <span>Found ${results.length} API${results.length > 1 ? 's' : ''} matching "${escapeHtml(query)}"</span>
                            </div>
                            <div class="api-search-list">
                                ${results.map(r => `
                                    <div class="api-search-item" data-app-name="${escapeHtml(r.appName)}" data-api-idx="${r.apiIndex}">
                                        <div class="api-search-item-header">
                                            <span class="api-search-app-name">${escapeHtml(r.appName)}</span>
                                            <span class="api-method-badge ${r.method}">${r.method}</span>
                                            <span class="api-search-api-name">${escapeHtml(r.name)}</span>
                                        </div>
                                        <div class="api-search-item-endpoint">${escapeHtml(r.endpoint)}</div>
                                        <button class="api-search-execute-btn" data-app-name="${escapeHtml(r.appName)}" data-api-idx="${r.apiIndex}">▶ Execute</button>
                                    </div>
                                `).join('')}
                            </div>
                        `;

                        // Attach execute button events
                        searchResultsContainer.querySelectorAll('.api-search-execute-btn').forEach(btn => {
                            btn.addEventListener('click', async (e) => {
                                e.stopPropagation();
                                const appName = btn.dataset.appName;
                                const apiIdx = parseInt(btn.dataset.apiIdx);
                                const config = await window.SMD2_AppApiManager.loadAppApiConfig(appName);
                                if (config.apis && config.apis[apiIdx]) {
                                    window.SMD2_AppApiManager.showApiExecuteModal(appName, config.apis[apiIdx]);
                                }
                            });
                        });
                    }

                    searchResultsContainer.style.display = 'block';
                    subPanel.querySelectorAll('.apps-grid, .apps-category-header').forEach(el => el.style.display = 'none');
                    searchStatus.textContent = `${results.length} result${results.length !== 1 ? 's' : ''}`;
                } catch (err) {
                    searchResultsContainer.innerHTML = `<div class="api-search-error">Error searching APIs: ${err.message}</div>`;
                    searchResultsContainer.style.display = 'block';
                    searchStatus.textContent = 'Error';
                } finally {
                    searchBtn.disabled = false;
                }
            }

            searchBtn.addEventListener('click', performApiSearch);
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') performApiSearch();
            });

            clearBtn.addEventListener('click', () => {
                searchInput.value = '';
                searchResultsContainer.style.display = 'none';
                searchResultsContainer.innerHTML = '';
                subPanel.querySelectorAll('.apps-grid, .apps-category-header').forEach(el => el.style.display = '');
                searchStatus.textContent = '';
                // Also collapse any expanded rows
                subPanel.querySelectorAll('.app-apis-expanded-row').forEach(r => r.remove());
                subPanel.querySelectorAll('.app-name-clickable.expanded').forEach(n => n.classList.remove('expanded'));
            });

            (grp.categories || []).forEach(cat => {
                if (grp.categories.length > 1) {
                    const catHdr = document.createElement('div');
                    catHdr.className = 'apps-category-header';
                    catHdr.style.marginTop = '1rem';
                    catHdr.textContent = cat.label;
                    subPanel.appendChild(catHdr);
                }
                subPanel.appendChild(buildAppTable(cat.apps || [], subPanel));
            });

            subPanelsWrap.appendChild(subPanel);
        });

        // AppConfig sub-tab - check if enabled in current env config
        // Gets the active env and checks appConfig.tabs.appConfig.enabled
        function isAppConfigEnabled() {
            const activeEnvBtn = document.querySelector('#current-env .env-toggle-btn.active');
            const env = activeEnvBtn ? activeEnvBtn.dataset.env : envKeys[0];
            const cfg = ENVS[env]?.appConfig;
            return !cfg || !cfg.tabs || !cfg.tabs.appConfig || cfg.tabs.appConfig.enabled !== false;
        }

        const appConfigSubId = '__apps_sub_appconfig__';
        let appConfigSubBtn = null;
        let appConfigPanel = null;

        if (isAppConfigEnabled()) {
            appConfigSubBtn = document.createElement('button');
            appConfigSubBtn.className = 'tab-button sub-tab-small';
            appConfigSubBtn.dataset.subTab = appConfigSubId;
            appConfigSubBtn.textContent = '⚙️ AppConfig';
            subBar.appendChild(appConfigSubBtn);

            appConfigPanel = createAppConfigPanel(ENVS, envKeys);
            appConfigPanel.id = appConfigSubId;
            appConfigPanel.className = 'cred-panel';
            subPanelsWrap.appendChild(appConfigPanel);
        }

        // Listen for environment changes to show/hide AppConfig tab
        document.getElementById('current-env')?.addEventListener('click', e => {
            const btn = e.target.closest('.env-toggle-btn');
            if (!btn) return;
            const env = btn.dataset.env;
            const cfg = ENVS[env]?.appConfig;
            const enabled = !cfg || !cfg.tabs || !cfg.tabs.appConfig || cfg.tabs.appConfig.enabled !== false;

            // Find existing AppConfig elements
            const existingBtn = subBar.querySelector(`[data-sub-tab="${appConfigSubId}"]`);
            const existingPanel = subPanelsWrap.querySelector(`#${appConfigSubId}`);

            if (enabled && !existingBtn) {
                // Create AppConfig tab if not exists
                const newBtn = document.createElement('button');
                newBtn.className = 'tab-button sub-tab-small';
                newBtn.dataset.subTab = appConfigSubId;
                newBtn.textContent = '⚙️ AppConfig';
                subBar.appendChild(newBtn);
                newBtn.addEventListener('click', () => {
                    subBar.querySelectorAll('[data-sub-tab]').forEach(b => b.classList.toggle('active', b === newBtn));
                    subPanelsWrap.querySelectorAll('.cred-panel').forEach(p => p.classList.toggle('active', p.id === newBtn.dataset.subTab));
                });

                if (!existingPanel) {
                    const newPanel = createAppConfigPanel(ENVS, envKeys);
                    newPanel.id = appConfigSubId;
                    newPanel.className = 'cred-panel';
                    subPanelsWrap.appendChild(newPanel);
                }
            } else if (!enabled && existingBtn) {
                // Hide/remove AppConfig tab if exists and disabled
                existingBtn.remove();
                if (existingPanel) {
                    // If AppConfig was active, switch to first available tab
                    if (existingPanel.classList.contains('active')) {
                        const firstBtn = subBar.querySelector('[data-sub-tab]');
                        const firstPanel = subPanelsWrap.querySelector('.cred-panel');
                        if (firstBtn) firstBtn.classList.add('active');
                        if (firstPanel) firstPanel.classList.add('active');
                    }
                    existingPanel.remove();
                }
            }
        });

        subBar.querySelectorAll('[data-sub-tab]').forEach(subBtn => {
            subBtn.addEventListener('click', () => {
                subBar.querySelectorAll('[data-sub-tab]').forEach(b => b.classList.toggle('active', b === subBtn));
                subPanelsWrap.querySelectorAll('.cred-panel').forEach(p => p.classList.toggle('active', p.id === subBtn.dataset.subTab));
            });
        });

        panel.appendChild(subBar);
        panel.appendChild(subPanelsWrap);
        panelsEl.appendChild(panel);
    }

    function createAppConfigPanel(ENVS, envKeys) {
        const panel = document.createElement('div');

        function getActiveEnv() {
            const active = document.querySelector('#current-env .env-toggle-btn.active');
            return active ? active.dataset.env : envKeys[0];
        }

        const configBar = document.createElement('div');
        configBar.className = 'mule-config-bar';
        configBar.style.flexWrap = 'wrap';
        configBar.innerHTML = `
            <div class="mule-config-item">
                <label>🔑 Access Token:</label>
                <input type="password" id="mule-access-token" placeholder="Mulesoft Access Token" style="min-width:250px;">
                <button type="button" id="mule-token-toggle" style="padding:0.3rem 0.5rem;border:1px solid #ccc;border-radius:4px;cursor:pointer;">👁️</button>
            </div>
            <div class="mule-config-item">
                <label>🏢 Org ID:</label>
                <input type="text" id="mule-org-id" placeholder="Organization ID" style="min-width:180px;">
            </div>
            <div class="mule-config-item">
                <label>🌍 Env ID:</label>
                <input type="text" id="mule-env-id" placeholder="Environment ID" style="min-width:180px;">
            </div>
            <div class="mule-config-item" style="gap:0.3rem;">
                <button type="button" id="mule-load-config-btn" style="padding:0.35rem 0.7rem;border:1px solid #17a2b8;border-radius:4px;background:#e3f2fd;color:#0277bd;font-weight:600;cursor:pointer;font-size:0.8rem;">📥 Load Config</button>
                <button type="button" id="mule-save-config-btn" style="padding:0.35rem 0.7rem;border:1px solid #28a745;border-radius:4px;background:#e8f5e9;color:#2e7d32;font-weight:600;cursor:pointer;font-size:0.8rem;">💾 Save Config</button>
            </div>
            <button type="button" id="mule-fetch-btn" class="mule-fetch-btn">🚀 Fetch Capacity</button>
            <button type="button" id="mule-report-btn" class="mule-report-btn" style="padding:0.4rem 0.8rem;border:1px solid #6f42c1;border-radius:4px;background:#f3e5f5;color:#6f42c1;font-weight:600;cursor:pointer;font-size:0.8rem;">📊 Generate Report</button>
        `;
        panel.appendChild(configBar);

        configBar.querySelector('#mule-token-toggle').addEventListener('click', () => {
            const tokenInput = configBar.querySelector('#mule-access-token');
            tokenInput.type = tokenInput.type === 'password' ? 'text' : 'password';
        });

        configBar.querySelector('#mule-load-config-btn').addEventListener('click', async () => {
            const env = getActiveEnv();
            const loadBtn = configBar.querySelector('#mule-load-config-btn');
            loadBtn.disabled = true;
            loadBtn.textContent = '⏳...';
            try {
                const resp = await fetch(`/api/mulesoft/config/${env}`);
                const config = await resp.json();
                if (config.orgId) document.getElementById('mule-org-id').value = config.orgId;
                if (config.envId) document.getElementById('mule-env-id').value = config.envId;
                if (config.accessToken) document.getElementById('mule-access-token').value = config.accessToken;
                loadBtn.textContent = '✓ Loaded';
                setTimeout(() => { loadBtn.textContent = '📥 Load Config'; }, 1500);
            } catch (err) {
                alert('Failed to load config: ' + err.message);
                loadBtn.textContent = '📥 Load Config';
            } finally {
                loadBtn.disabled = false;
            }
        });

        configBar.querySelector('#mule-save-config-btn').addEventListener('click', async () => {
            const env = getActiveEnv();
            const saveBtn = configBar.querySelector('#mule-save-config-btn');
            saveBtn.disabled = true;
            saveBtn.textContent = '⏳...';
            try {
                const resp = await fetch('/api/mulesoft/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        env,
                        orgId: document.getElementById('mule-org-id').value.trim(),
                        envId: document.getElementById('mule-env-id').value.trim(),
                        accessToken: document.getElementById('mule-access-token').value.trim()
                    })
                });
                const result = await resp.json();
                if (result.success) {
                    saveBtn.textContent = '✓ Saved';
                    setTimeout(() => { saveBtn.textContent = '💾 Save Config'; }, 1500);
                } else {
                    throw new Error(result.error || 'Unknown error');
                }
            } catch (err) {
                alert('Failed to save config: ' + err.message);
                saveBtn.textContent = '💾 Save Config';
            } finally {
                saveBtn.disabled = false;
            }
        });

        const filterBar = document.createElement('div');
        filterBar.className = 'mule-app-filter';
        filterBar.innerHTML = `
            <label style="font-weight:600;font-size:0.82rem;color:#555;">🔍 Filter Apps:</label>
            <input type="text" id="mule-app-filter" placeholder="e.g., cdp-smd2" value="cdp-smd2">
            <span style="font-size:0.78rem;color:#666;">(Leave empty to show all)</span>
        `;
        panel.appendChild(filterBar);

        const summaryCards = document.createElement('div');
        summaryCards.className = 'mule-summary-cards';
        summaryCards.innerHTML = `
            <div class="mule-summary-card">
                <div class="value" id="mule-total-apps">—</div>
                <div class="label">Total Apps</div>
            </div>
            <div class="mule-summary-card">
                <div class="value" id="mule-total-cpu">—</div>
                <div class="label">Total CPU (vCPU)</div>
            </div>
            <div class="mule-summary-card">
                <div class="value" id="mule-total-memory">—</div>
                <div class="label">Total Memory (GB)</div>
            </div>
            <div class="mule-summary-card">
                <div class="value" id="mule-total-replicas">—</div>
                <div class="label">Total Replicas</div>
            </div>
        `;
        panel.appendChild(summaryCards);

        const tableWrap = document.createElement('div');
        tableWrap.style.cssText = 'overflow-x:auto;';
        const capacityTable = document.createElement('table');
        capacityTable.className = 'mule-capacity-table';
        const capacityThead = document.createElement('thead');
        capacityThead.innerHTML = `
            <tr>
                <th>App Name</th>
                <th style="text-align:center;">API ID</th>
                <th style="text-align:center;">Status</th>
                <th style="text-align:center;">CPU Reserved (vCPU)</th>
                <th style="text-align:center;">CPU Limit (vCPU)</th>
                <th style="text-align:center;">Memory (GB)</th>
                <th style="text-align:center;">Replicas</th>
                <th style="text-align:center;">Runtime</th>
                <th style="text-align:center;">JDK</th>
            </tr>
        `;
        capacityTable.appendChild(capacityThead);
        const capacityTbody = document.createElement('tbody');
        capacityTbody.innerHTML = `
            <tr>
                <td colspan="9" style="text-align:center;color:#888;padding:2rem;">
                    Load config or enter credentials, then click "Fetch Capacity"
                </td>
            </tr>
        `;
        capacityTable.appendChild(capacityTbody);
        tableWrap.appendChild(capacityTable);
        panel.appendChild(tableWrap);

        const statusMsg = document.createElement('div');
        statusMsg.style.cssText = 'margin-top:0.75rem;font-size:0.82rem;color:#666;';
        panel.appendChild(statusMsg);

        let lastFetchResults = null;

        const fetchBtn = configBar.querySelector('#mule-fetch-btn');
        fetchBtn.addEventListener('click', async () => {
            const accessToken = document.getElementById('mule-access-token').value.trim();
            const orgId = document.getElementById('mule-org-id').value.trim();
            const envId = document.getElementById('mule-env-id').value.trim();
            const appFilter = document.getElementById('mule-app-filter').value.trim();

            if (!accessToken || !orgId || !envId) {
                statusMsg.innerHTML = '<span style="color:#dc3545;">⚠️ Please provide Access Token, Org ID, and Env ID (or Load Config)</span>';
                return;
            }

            fetchBtn.disabled = true;
            fetchBtn.textContent = '⏳ Fetching...';
            statusMsg.textContent = 'Fetching capacity data from server...';

            try {
                const env = getActiveEnv();
                const resp = await fetch('/api/appconfig/capacity', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ env, accessToken, orgId, envId, appFilter })
                });

                const data = await resp.json();
                if (!data.success) {
                    throw new Error(data.error || 'Unknown error');
                }

                const { results, totals, apiLog, fetchedAt } = data;
                lastFetchResults = data;

                summaryCards.querySelector('#mule-total-apps').textContent = results.length;
                summaryCards.querySelector('#mule-total-cpu').textContent = totals.reservedCpu.toFixed(2);
                summaryCards.querySelector('#mule-total-memory').textContent = totals.memoryGb.toFixed(2);
                summaryCards.querySelector('#mule-total-replicas').textContent = totals.replicas;

                capacityTbody.innerHTML = results.map(r => `
                    <tr>
                        <td>${r.appName}</td>
                        <td style="text-align:center;">${r.apiId}</td>
                        <td style="text-align:center;"><span class="mule-status-badge ${r.status}">${r.status}</span></td>
                        <td style="text-align:center;">${r.reservedCpu.toFixed(2)}</td>
                        <td style="text-align:center;">${r.cpuLimit.toFixed(2)}</td>
                        <td style="text-align:center;">${r.memoryGb.toFixed(2)}</td>
                        <td style="text-align:center;">${r.replicas}</td>
                        <td style="text-align:center;">${r.runtimeVersion}</td>
                        <td style="text-align:center;">${r.jdkVersion}</td>
                    </tr>
                `).join('') + `
                    <tr class="total-row">
                        <td colspan="3"><strong>TOTAL</strong></td>
                        <td style="text-align:center;"><strong>${totals.reservedCpu.toFixed(2)}</strong></td>
                        <td style="text-align:center;"><strong>${totals.cpuLimit.toFixed(2)}</strong></td>
                        <td style="text-align:center;"><strong>${totals.memoryGb.toFixed(2)}</strong></td>
                        <td style="text-align:center;"><strong>${totals.replicas}</strong></td>
                        <td colspan="2"></td>
                    </tr>
                `;

                const apiLogCount = apiLog.filter(l => l.status === 'success').length;
                statusMsg.innerHTML = `<span style="color:#28a745;">✅ Loaded ${results.length} apps (${apiLogCount} API calls) at ${new Date(fetchedAt).toLocaleTimeString()}</span>`;

            } catch (err) {
                statusMsg.innerHTML = `<span style="color:#dc3545;">❌ Error: ${err.message}</span>`;
                console.error('Mule capacity fetch error:', err);
            } finally {
                fetchBtn.disabled = false;
                fetchBtn.textContent = '🚀 Fetch Capacity';
            }
        });

        const reportBtn = configBar.querySelector('#mule-report-btn');
        reportBtn.addEventListener('click', () => {
            showReportModal(getActiveEnv);
        });

        return panel;
    }

    function showReportModal(getActiveEnv) {
        const existingModal = document.getElementById('mule-report-modal');
        if (existingModal) existingModal.remove();

        const modal = document.createElement('div');
        modal.id = 'mule-report-modal';
        modal.className = 'run-all-modal-overlay';
        modal.innerHTML = `
            <div class="run-all-modal-content" style="max-width:500px;">
                <div class="run-all-modal-header">
                    <span class="run-all-modal-title">📊 Generate Capacity Report</span>
                    <button class="run-all-modal-close">&times;</button>
                </div>
                <div class="config-params-body">
                    <div class="config-section">
                        <strong>Report Format:</strong>
                        <div style="display:flex;gap:12px;margin-top:8px;">
                            <label style="display:flex;align-items:center;gap:6px;">
                                <input type="radio" name="report-format" value="json" checked>
                                <span>JSON</span>
                            </label>
                            <label style="display:flex;align-items:center;gap:6px;">
                                <input type="radio" name="report-format" value="csv">
                                <span>CSV</span>
                            </label>
                            <label style="display:flex;align-items:center;gap:6px;">
                                <input type="radio" name="report-format" value="markdown">
                                <span>Markdown</span>
                            </label>
                        </div>
                    </div>
                    <div class="config-section" style="margin-top:12px;">
                        <p style="font-size:0.85rem;color:#666;">
                            This will fetch fresh data from the Mulesoft API and generate a downloadable report.
                            All API calls are logged on the server for auditing.
                        </p>
                    </div>
                </div>
                <div class="config-params-footer">
                    <button class="pcopy report-generate-btn" style="background:#6f42c1;color:white;padding:6px 16px;">📥 Generate & Download</button>
                    <button class="pcopy report-cancel-btn" style="padding:6px 16px;">Cancel</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        modal.querySelector('.run-all-modal-close').addEventListener('click', () => modal.remove());
        modal.querySelector('.report-cancel-btn').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });

        modal.querySelector('.report-generate-btn').addEventListener('click', async () => {
            const format = modal.querySelector('input[name="report-format"]:checked').value;
            const accessToken = document.getElementById('mule-access-token').value.trim();
            const orgId = document.getElementById('mule-org-id').value.trim();
            const envId = document.getElementById('mule-env-id').value.trim();
            const appFilter = document.getElementById('mule-app-filter').value.trim();
            const env = getActiveEnv();

            if (!accessToken || !orgId || !envId) {
                alert('Please provide Access Token, Org ID, and Env ID first');
                return;
            }

            const btn = modal.querySelector('.report-generate-btn');
            btn.disabled = true;
            btn.textContent = '⏳ Generating...';

            try {
                const resp = await fetch('/api/appconfig/report', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ env, accessToken, orgId, envId, appFilter, format })
                });

                if (!resp.ok) {
                    const err = await resp.json();
                    throw new Error(err.error || 'Failed to generate report');
                }

                const blob = await resp.blob();
                const extensions = { json: 'json', csv: 'csv', markdown: 'md' };
                const filename = `mulesoft-capacity-${env}-${new Date().toISOString().split('T')[0]}.${extensions[format]}`;

                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = filename;
                a.click();
                URL.revokeObjectURL(url);

                btn.textContent = '✓ Downloaded!';
                setTimeout(() => modal.remove(), 1500);
            } catch (err) {
                alert('Error: ' + err.message);
                btn.textContent = '📥 Generate & Download';
                btn.disabled = false;
            }
        });
    }

    window.SMD2_MuleAppsTab = {
        render: renderMuleAppsTab
    };

})(window);
