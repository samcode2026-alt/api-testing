// Mule Apps list for the 🔌 Mule Apps tab.
// Structured as tab groups — each becomes a sub-tab (EAPI, PAPI, SAPI, Batch Jobs).
// Each tab group has one or more categories, each with a list of app names.
//
// Link templates: use {app} as placeholder for the app name.
window.SMD2_APP_LINK_TEMPLATES = {
    elk: "https://elasticsearch-prod.comp.pge.com/s/app-3459-mulesoft-rtf-eks/app/discover#/?_g=(filters:!(),refreshInterval:(pause:!t,value:60000),time:(from:now-24h%2Fh,to:now))&_a=(columns:!(log),dataSource:(dataViewId:b4f5b2da-e8a6-44c7-8294-72e858016d7d,type:dataView),filters:!(),hideChart:!f,interval:auto,query:(language:kuery,query:%22{app}%22),sort:!(!('@timestamp',desc)))",
    monitor: 'https://anypoint.mulesoft.com/monitoring/#/builtin/0429580b-0226-48b7-b422-0189efd8db17/mc/391609ce-b3e4-445a-b9d6-29bbdf597326/performance',
    insights: 'https://anypoint.mulesoft.com/monitoring-new/organizations/367138ef-c834-4f8f-b851-556593787fe3/environments/0429580b-0226-48b7-b422-0189efd8db17/api-detail-page/{app}/20533175?api-detail-page-date-time-range-settings=%7B%22range%22%3A%7B%22format%22%3A%22hours%22%2C%22amount%22%3A1%7D%2C%22autoRefreshChecked%22%3Atrue%2C%22refreshInterval%22%3A%221m%22%7D&api-detail-page-date-time-range=%7B%22startTime%22%3A1780854900000%2C%22endTime%22%3A1780858500000%7D&api-detail-with-resource-selector-params=%7B%7D',
    git: 'https://github.com/pgetech/{app}',
    exchange: 'https://anypoint.mulesoft.com/exchange/367138ef-c834-4f8f-b851-556593787fe3/{app}/minor/1.0/console/summary/'
};

window.SMD2_MULE_APPS = [
    {
        tab: "Proxy Apps",
        icon: "🌐",
        categories: [
            {
                label: "Proxy App (SRT)",
                apps: [
                    { name: "cdp-smd2-datacustodian-proxy" , business_group: "EI"},
                    { name: "cdp-smd2-datacustodian-sandbox-proxy" , business_group: "EI" },
                    { name: "cdp-smd2-greenbuttonconnect-proxy" , business_group: "EI" },
                    { name: "cdp-smd2-portal-proxy" , business_group: "EI" }
                ]
            }
        ]
    },
    {
        tab: "EAPI",
        icon: "🌐",
        categories: [
            {
                label: "Experience API (RTF)",
                apps: [
                    { name: "cdp-smd2-customerinfo-eapi" , business_group: "ShareMyData" },
                    { name: "cdp-smd2-drprginfo-eapi" , business_group: "ShareMyData" },
                    { name: "cdp-smd2-oauth-eapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-odata-eapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-portal-eapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-services-eapi" , business_group: "ShareMyData" },
                    { name: "cdp-smd2-subscriptions-eapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-uc4-eapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-vendor-sandbox-eapi" , business_group: "ShareMyData" }
                ]
            }
        ]
    },
    {
        tab: "PAPI",
        icon: "⚙️",
        categories: [
            {
                label: "Process API (RTF)",
                apps: [
                    { name: "cdp-smd2-accounts-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-appinfo-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-application-information-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-authorizations-batch-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-authorizations-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-ccb-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-cisr-auth-batch-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-cisr-batch-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-client-notification-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-clients-download-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-data-sync-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dd-cca-elecbill-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dd-cca-elecusage-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dd-non-cca-elecbill-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dd-non-cca-elecusage-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dd-non-cca-gasbill-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dd-non-cca-gasusage-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dr-program-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-drp-meter-batch-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-gbc-subs-batch-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-oauth-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-registration-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-retail-customer-info-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-rule24-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-subscriptions-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-subscriptions-usage-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-svc-agreements-papi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-usage-point-papi" , business_group: "DataProducts" }
                ]
            }
        ]
    },
    {
        tab: "SAPI",
        icon: "🔧",
        categories: [
            {
                label: "System API (RTF)",
                apps: [
                    { name: "cdp-smd2-billing-teradata-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-caiso-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-cih-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-clients-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-clients-smd-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-customers-teradata-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-oauth-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-odata-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-resource-owner-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-rule24-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-salesforce-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-subscriptions-sapi" , business_group: "DataProducts" },
                    { name: "cdp-smd2-usage-teradata-sapi" , business_group: "DataProducts" }
                ]
            },
            {
                label: "OAuth Setup",
                apps: [
                    { name: "cdp-smd2-anypoint-platform-sapi" , business_group: "EI" }
                ]
            }
        ]
    },
    {
        tab: "Batch Jobs",
        icon: "📦",
        categories: [
            {
                label: "Batch Jobs (RTF)",
                apps: [
                    { name: "cdp-smd2-add-delete-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-auth-processor-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-batch-bulk-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-batch-bulk-customer-info-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-batch-subscription-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-caiso-batch-status-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-caiso-registration-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-caiso-retrieve-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-caiso-review-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-caiso-submit-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-ccb-char-batch-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-cisr-processor-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-clients-migration-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-cust-auth-report-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dr-prg-info-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-dr-program-app" , business_group: "DataProducts" },
                    { name: "cdp-smd2-req2interval-app" , business_group: "DataProducts" }
                ]
            }
        ]
    }
];
