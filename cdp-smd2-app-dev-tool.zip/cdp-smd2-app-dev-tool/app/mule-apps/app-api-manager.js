// App API Manager Module
// Provides UI for configuring and executing per-app APIs
// Integrates with the Mule Apps tab

(function(window) {
    'use strict';

    function getActiveEnv() {
        const active = document.querySelector('#current-env .env-toggle-btn.active');
        return active ? active.dataset.env : 'dev';
    }

    async function loadAppApiConfig(appName) {
        try {
            const response = await fetch(`/api/app-apis/${encodeURIComponent(appName)}`);
            return await response.json();
        } catch (err) {
            console.error('Failed to load app API config:', err);
            return { appName, apis: [] };
        }
    }

    async function saveAppApiConfig(appName, config) {
        try {
            const response = await fetch(`/api/app-apis/${encodeURIComponent(appName)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            });
            return await response.json();
        } catch (err) {
            console.error('Failed to save app API config:', err);
            return { success: false, error: err.message };
        }
    }

    async function executeApi(apiConfig, env, paramValues = {}) {
        const envOverride = apiConfig.envOverrides?.[env] || {};
        const baseUrl = envOverride.baseUrl || apiConfig.baseUrl || '';

        let endpoint = apiConfig.endpoint || '';

        (apiConfig.pathParams || []).forEach(p => {
            const value = paramValues[`path_${p.key}`] || p.defaultValue || '';
            endpoint = endpoint.replace(`{${p.key}}`, encodeURIComponent(value));
        });

        const queryParams = (apiConfig.queryParams || [])
            .filter(p => p.enabled !== false)
            .map(p => {
                const value = paramValues[`query_${p.key}`] !== undefined ? paramValues[`query_${p.key}`] : p.value;
                return value ? `${encodeURIComponent(p.key)}=${encodeURIComponent(value)}` : null;
            })
            .filter(Boolean)
            .join('&');

        const fullUrl = baseUrl + endpoint + (queryParams ? '?' + queryParams : '');

        const headers = {};
        (apiConfig.headers || [])
            .filter(h => h.enabled !== false)
            .forEach(h => {
                let value = paramValues[`header_${h.key}`] !== undefined ? paramValues[`header_${h.key}`] : h.value;
                headers[h.key] = value;
            });

        let body = null;
        let bodyType = null;
        if (apiConfig.body && ['POST', 'PUT', 'PATCH'].includes(apiConfig.method)) {
            bodyType = apiConfig.body.type;
            if (bodyType === 'json') {
                const content = paramValues.body_raw !== undefined ? paramValues.body_raw : apiConfig.body.content;
                body = typeof content === 'string' ? content : JSON.stringify(content);
            } else if (bodyType === 'form') {
                body = {};
                (apiConfig.body.fields || [])
                    .filter(f => f.enabled !== false)
                    .forEach(f => {
                        body[f.key] = paramValues[`body_${f.key}`] !== undefined ? paramValues[`body_${f.key}`] : f.value;
                    });
            } else if (bodyType === 'raw') {
                body = paramValues.body_raw !== undefined ? paramValues.body_raw : apiConfig.body.content;
            }
        }

        try {
            const response = await fetch('/api/app-apis/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    method: apiConfig.method,
                    url: fullUrl,
                    headers,
                    body,
                    bodyType
                })
            });
            return await response.json();
        } catch (err) {
            return { error: err.message };
        }
    }

    function showApiConfigModal(appName, onSave) {
        const existingModal = document.getElementById('app-api-config-modal');
        if (existingModal) existingModal.remove();

        const modal = document.createElement('div');
        modal.id = 'app-api-config-modal';
        modal.className = 'run-all-modal-overlay';
        modal.innerHTML = `
            <div class="run-all-modal-content" style="max-width:950px;max-height:90vh;">
                <div class="run-all-modal-header">
                    <span class="run-all-modal-title">Configure APIs for ${appName}</span>
                    <button class="run-all-modal-close">&times;</button>
                </div>
                <div class="config-params-body" style="max-height:calc(90vh - 120px);overflow-y:auto;padding:1rem;">
                    <div class="api-config-toolbar">
                        <button type="button" class="add-api-btn">+ Add API</button>
                    </div>
                    <div class="api-list-container"></div>
                </div>
                <div class="config-params-footer">
                    <button class="pcopy save-config-btn" style="background:#28a745;color:white;">Save Configuration</button>
                    <button class="pcopy cancel-btn">Cancel</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        const apiListContainer = modal.querySelector('.api-list-container');
        let apis = [];

        loadAppApiConfig(appName).then(config => {
            apis = config.apis || [];
            renderApiList();
        });

        function renderApiList() {
            if (apis.length === 0) {
                apiListContainer.innerHTML = '<div class="no-apis-message">No APIs configured. Click "+ Add API" to create one.</div>';
                return;
            }

            apiListContainer.innerHTML = apis.map((api, idx) => `
                <div class="api-config-card" data-idx="${idx}">
                    <div class="api-config-header">
                        <select class="method-select">
                            ${['GET','POST','PUT','PATCH','DELETE'].map(m =>
                                `<option value="${m}" ${api.method === m ? 'selected' : ''}>${m}</option>`
                            ).join('')}
                        </select>
                        <input type="text" class="api-name-input" value="${escapeHtml(api.name || '')}" placeholder="API Name">
                        <input type="text" class="api-endpoint-input" value="${escapeHtml(api.endpoint || '')}" placeholder="/api/endpoint/{id}">
                        <button type="button" class="delete-api-btn" data-idx="${idx}">Delete</button>
                    </div>
                    <div class="api-config-details">
                        <div class="api-config-section env-overrides-section">
                            <strong>Environment Base URLs:</strong>
                            <div class="env-overrides-grid">
                                ${['local', 'dev', 'qa', 'uat'].map(env => `
                                    <div class="env-override-row">
                                        <label>${env.toUpperCase()}:</label>
                                        <input type="text" class="env-url-input" data-env="${env}"
                                               value="${escapeHtml(api.envOverrides?.[env]?.baseUrl || '')}"
                                               placeholder="http://localhost:8081 or https://api-xxx.pge.com">
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                        <div class="api-config-section">
                            <strong>Headers:</strong>
                            <div class="headers-list">
                                ${(api.headers || []).map((h, hi) => `
                                    <div class="param-row" data-type="header" data-hi="${hi}">
                                        <input type="checkbox" class="param-enabled" ${h.enabled !== false ? 'checked' : ''}>
                                        <input type="text" class="param-key" value="${escapeHtml(h.key || '')}" placeholder="Key">
                                        <input type="text" class="param-value" value="${escapeHtml(h.value || '')}" placeholder="Value">
                                        <button type="button" class="remove-param-btn">-</button>
                                    </div>
                                `).join('')}
                            </div>
                            <button type="button" class="add-header-btn">+ Add Header</button>
                        </div>
                        <div class="api-config-section">
                            <strong>Query Parameters:</strong>
                            <div class="query-params-list">
                                ${(api.queryParams || []).map((p, pi) => `
                                    <div class="param-row" data-type="query" data-pi="${pi}">
                                        <input type="checkbox" class="param-enabled" ${p.enabled !== false ? 'checked' : ''}>
                                        <input type="text" class="param-key" value="${escapeHtml(p.key || '')}" placeholder="Key">
                                        <input type="text" class="param-value" value="${escapeHtml(p.value || '')}" placeholder="Value">
                                        <button type="button" class="remove-param-btn">-</button>
                                    </div>
                                `).join('')}
                            </div>
                            <button type="button" class="add-query-param-btn">+ Add Query Param</button>
                        </div>
                        <div class="api-config-section">
                            <strong>Path Parameters:</strong>
                            <div class="path-params-list">
                                ${(api.pathParams || []).map((p, pi) => `
                                    <div class="param-row" data-type="path" data-pi="${pi}">
                                        <input type="text" class="param-key" value="${escapeHtml(p.key || '')}" placeholder="Key (e.g., id)">
                                        <input type="text" class="param-default" value="${escapeHtml(p.defaultValue || '')}" placeholder="Default Value">
                                        <button type="button" class="remove-param-btn">-</button>
                                    </div>
                                `).join('')}
                            </div>
                            <button type="button" class="add-path-param-btn">+ Add Path Param</button>
                        </div>
                        <div class="api-config-section">
                            <strong>Request Body:</strong>
                            <div class="body-config">
                                <select class="body-type-select">
                                    <option value="none" ${!api.body ? 'selected' : ''}>None</option>
                                    <option value="json" ${api.body?.type === 'json' ? 'selected' : ''}>JSON</option>
                                    <option value="form" ${api.body?.type === 'form' ? 'selected' : ''}>Form URL Encoded</option>
                                    <option value="raw" ${api.body?.type === 'raw' ? 'selected' : ''}>Raw</option>
                                </select>
                                <div class="body-content-area" style="${api.body ? '' : 'display:none;'}">
                                    ${api.body?.type === 'form' ? `
                                        <div class="body-form-fields">
                                            ${(api.body.fields || []).map((f, fi) => `
                                                <div class="param-row" data-type="body" data-fi="${fi}">
                                                    <input type="checkbox" class="param-enabled" ${f.enabled !== false ? 'checked' : ''}>
                                                    <input type="text" class="param-key" value="${escapeHtml(f.key || '')}" placeholder="Key">
                                                    <input type="text" class="param-value" value="${escapeHtml(f.value || '')}" placeholder="Value">
                                                    <button type="button" class="remove-param-btn">-</button>
                                                </div>
                                            `).join('')}
                                        </div>
                                        <button type="button" class="add-body-field-btn">+ Add Field</button>
                                    ` : `
                                        <textarea class="body-content-input" rows="4" placeholder="Request body content">${escapeHtml(api.body?.content || '')}</textarea>
                                    `}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `).join('');

            attachApiCardEvents();
        }

        function attachApiCardEvents() {
            modal.querySelectorAll('.api-config-card').forEach(card => {
                const idx = parseInt(card.dataset.idx);

                card.querySelector('.method-select').addEventListener('change', e => {
                    apis[idx].method = e.target.value;
                });

                card.querySelector('.api-name-input').addEventListener('input', e => {
                    apis[idx].name = e.target.value;
                });

                card.querySelector('.api-endpoint-input').addEventListener('input', e => {
                    apis[idx].endpoint = e.target.value;
                });

                card.querySelector('.delete-api-btn').addEventListener('click', () => {
                    apis.splice(idx, 1);
                    renderApiList();
                });

                card.querySelectorAll('.env-url-input').forEach(inp => {
                    inp.addEventListener('input', () => {
                        const env = inp.dataset.env;
                        if (!apis[idx].envOverrides) apis[idx].envOverrides = {};
                        if (!apis[idx].envOverrides[env]) apis[idx].envOverrides[env] = {};
                        apis[idx].envOverrides[env].baseUrl = inp.value;
                    });
                });

                card.querySelectorAll('.headers-list .param-row').forEach((row, hi) => {
                    attachParamRowEvents(row, apis[idx], 'headers', hi);
                });

                card.querySelectorAll('.query-params-list .param-row').forEach((row, pi) => {
                    attachParamRowEvents(row, apis[idx], 'queryParams', pi);
                });

                card.querySelectorAll('.path-params-list .param-row').forEach((row, pi) => {
                    attachPathParamRowEvents(row, apis[idx], pi);
                });

                card.querySelectorAll('.body-form-fields .param-row').forEach((row, fi) => {
                    attachBodyFieldRowEvents(row, apis[idx], fi);
                });

                card.querySelector('.add-header-btn').addEventListener('click', () => {
                    if (!apis[idx].headers) apis[idx].headers = [];
                    apis[idx].headers.push({ key: '', value: '', enabled: true });
                    renderApiList();
                });

                card.querySelector('.add-query-param-btn').addEventListener('click', () => {
                    if (!apis[idx].queryParams) apis[idx].queryParams = [];
                    apis[idx].queryParams.push({ key: '', value: '', enabled: true });
                    renderApiList();
                });

                card.querySelector('.add-path-param-btn').addEventListener('click', () => {
                    if (!apis[idx].pathParams) apis[idx].pathParams = [];
                    apis[idx].pathParams.push({ key: '', defaultValue: '' });
                    renderApiList();
                });

                const bodyTypeSelect = card.querySelector('.body-type-select');
                bodyTypeSelect.addEventListener('change', () => {
                    const type = bodyTypeSelect.value;
                    if (type === 'none') {
                        apis[idx].body = null;
                    } else {
                        apis[idx].body = { type, content: '', fields: [] };
                    }
                    renderApiList();
                });

                const addBodyFieldBtn = card.querySelector('.add-body-field-btn');
                if (addBodyFieldBtn) {
                    addBodyFieldBtn.addEventListener('click', () => {
                        if (!apis[idx].body) apis[idx].body = { type: 'form', fields: [] };
                        if (!apis[idx].body.fields) apis[idx].body.fields = [];
                        apis[idx].body.fields.push({ key: '', value: '', enabled: true });
                        renderApiList();
                    });
                }

                const bodyContentInput = card.querySelector('.body-content-input');
                if (bodyContentInput) {
                    bodyContentInput.addEventListener('input', () => {
                        if (apis[idx].body) {
                            apis[idx].body.content = bodyContentInput.value;
                        }
                    });
                }
            });
        }

        function attachParamRowEvents(row, api, listKey, index) {
            const enabledCb = row.querySelector('.param-enabled');
            const keyInput = row.querySelector('.param-key');
            const valueInput = row.querySelector('.param-value');
            const removeBtn = row.querySelector('.remove-param-btn');

            if (enabledCb) {
                enabledCb.addEventListener('change', () => {
                    api[listKey][index].enabled = enabledCb.checked;
                });
            }
            keyInput.addEventListener('input', () => {
                api[listKey][index].key = keyInput.value;
            });
            valueInput.addEventListener('input', () => {
                api[listKey][index].value = valueInput.value;
            });
            removeBtn.addEventListener('click', () => {
                api[listKey].splice(index, 1);
                renderApiList();
            });
        }

        function attachPathParamRowEvents(row, api, index) {
            const keyInput = row.querySelector('.param-key');
            const defaultInput = row.querySelector('.param-default');
            const removeBtn = row.querySelector('.remove-param-btn');

            keyInput.addEventListener('input', () => {
                api.pathParams[index].key = keyInput.value;
            });
            defaultInput.addEventListener('input', () => {
                api.pathParams[index].defaultValue = defaultInput.value;
            });
            removeBtn.addEventListener('click', () => {
                api.pathParams.splice(index, 1);
                renderApiList();
            });
        }

        function attachBodyFieldRowEvents(row, api, index) {
            const enabledCb = row.querySelector('.param-enabled');
            const keyInput = row.querySelector('.param-key');
            const valueInput = row.querySelector('.param-value');
            const removeBtn = row.querySelector('.remove-param-btn');

            if (enabledCb) {
                enabledCb.addEventListener('change', () => {
                    api.body.fields[index].enabled = enabledCb.checked;
                });
            }
            keyInput.addEventListener('input', () => {
                api.body.fields[index].key = keyInput.value;
            });
            valueInput.addEventListener('input', () => {
                api.body.fields[index].value = valueInput.value;
            });
            removeBtn.addEventListener('click', () => {
                api.body.fields.splice(index, 1);
                renderApiList();
            });
        }

        modal.querySelector('.add-api-btn').addEventListener('click', () => {
            apis.push({
                id: 'api-' + Date.now(),
                name: 'New API',
                method: 'GET',
                endpoint: '/api/',
                headers: [{ key: 'Accept', value: 'application/json', enabled: true }],
                queryParams: [],
                pathParams: [],
                body: null,
                envOverrides: {}
            });
            renderApiList();
        });

        modal.querySelector('.run-all-modal-close').addEventListener('click', () => modal.remove());
        modal.querySelector('.cancel-btn').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', e => {
            if (e.target === modal) modal.remove();
        });

        modal.querySelector('.save-config-btn').addEventListener('click', async () => {
            const btn = modal.querySelector('.save-config-btn');
            btn.disabled = true;
            btn.textContent = 'Saving...';

            const result = await saveAppApiConfig(appName, { appName, apis });

            if (result.success) {
                btn.textContent = 'Saved!';
                setTimeout(() => {
                    modal.remove();
                    if (onSave) onSave();
                }, 800);
            } else {
                btn.textContent = 'Save Configuration';
                btn.disabled = false;
                alert('Failed to save: ' + (result.error || 'Unknown error'));
            }
        });
    }

    function showApiExecuteModal(appName, apiConfig) {
        const existingModal = document.getElementById('app-api-execute-modal');
        if (existingModal) existingModal.remove();

        const env = getActiveEnv();
        const envOverride = apiConfig.envOverrides?.[env] || {};
        const baseUrl = envOverride.baseUrl || '';

        const modal = document.createElement('div');
        modal.id = 'app-api-execute-modal';
        modal.className = 'run-all-modal-overlay';
        modal.innerHTML = `
            <div class="run-all-modal-content" style="max-width:1000px;max-height:90vh;">
                <div class="run-all-modal-header">
                    <span class="run-all-modal-title">
                        <span class="api-method-badge ${apiConfig.method}">${apiConfig.method}</span>
                        ${escapeHtml(apiConfig.name)} - ${escapeHtml(appName)}
                    </span>
                    <button class="run-all-modal-close">&times;</button>
                </div>
                <div class="config-params-body" style="max-height:calc(90vh - 120px);overflow-y:auto;padding:1rem;">
                    <div class="execute-url-preview">
                        <label>URL:</label>
                        <code class="url-preview-text">${escapeHtml(baseUrl)}${escapeHtml(apiConfig.endpoint)}</code>
                    </div>

                    ${(apiConfig.pathParams || []).length > 0 ? `
                    <div class="execute-params-section">
                        <h4>Path Parameters</h4>
                        <div class="path-params-inputs">
                            ${(apiConfig.pathParams || []).map(p => `
                                <div class="param-input-row">
                                    <label>{${escapeHtml(p.key)}}:</label>
                                    <input type="text" class="path-param-input" data-key="${escapeHtml(p.key)}"
                                           value="${escapeHtml(p.defaultValue || '')}" placeholder="Enter ${escapeHtml(p.key)}">
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    ` : ''}

                    ${(apiConfig.queryParams || []).filter(p => p.enabled !== false).length > 0 ? `
                    <div class="execute-params-section">
                        <h4>Query Parameters</h4>
                        <div class="query-params-inputs">
                            ${(apiConfig.queryParams || []).filter(p => p.enabled !== false).map(p => `
                                <div class="param-input-row">
                                    <label>${escapeHtml(p.key)}:</label>
                                    <input type="text" class="query-param-input" data-key="${escapeHtml(p.key)}"
                                           value="${escapeHtml(p.value || '')}" placeholder="Enter ${escapeHtml(p.key)}">
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    ` : ''}

                    ${(apiConfig.headers || []).filter(h => h.enabled !== false).length > 0 ? `
                    <div class="execute-params-section">
                        <h4>Headers</h4>
                        <div class="headers-inputs">
                            ${(apiConfig.headers || []).filter(h => h.enabled !== false).map(h => `
                                <div class="param-input-row">
                                    <label>${escapeHtml(h.key)}:</label>
                                    <input type="text" class="header-input" data-key="${escapeHtml(h.key)}"
                                           value="${escapeHtml(h.value || '')}" placeholder="Enter ${escapeHtml(h.key)}">
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    ` : ''}

                    ${apiConfig.body ? `
                    <div class="execute-params-section">
                        <h4>Request Body (${apiConfig.body.type})</h4>
                        <div class="body-inputs">
                            ${apiConfig.body.type === 'form' ?
                                (apiConfig.body.fields || []).filter(f => f.enabled !== false).map(f => `
                                    <div class="param-input-row">
                                        <label>${escapeHtml(f.key)}:</label>
                                        <input type="text" class="body-field-input" data-key="${escapeHtml(f.key)}"
                                               value="${escapeHtml(f.value || '')}" placeholder="Enter ${escapeHtml(f.key)}">
                                    </div>
                                `).join('')
                            : `<textarea class="body-raw-input" rows="5" placeholder="Request body">${escapeHtml(apiConfig.body.content || '')}</textarea>`}
                        </div>
                    </div>
                    ` : ''}

                    <div class="execute-response-section">
                        <h4>Response</h4>
                        <div class="response-meta"></div>
                        <pre class="response-body">Click "Execute" to send the request</pre>
                    </div>
                </div>
                <div class="config-params-footer">
                    <button class="pcopy execute-btn" style="background:#0a66c2;color:white;">Execute</button>
                    <button class="pcopy close-btn">Close</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        modal.querySelector('.run-all-modal-close').addEventListener('click', () => modal.remove());
        modal.querySelector('.close-btn').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', e => {
            if (e.target === modal) modal.remove();
        });

        modal.querySelector('.execute-btn').addEventListener('click', async () => {
            const btn = modal.querySelector('.execute-btn');
            btn.disabled = true;
            btn.textContent = 'Executing...';

            const paramValues = {};

            modal.querySelectorAll('.path-param-input').forEach(inp => {
                paramValues[`path_${inp.dataset.key}`] = inp.value;
            });

            modal.querySelectorAll('.query-param-input').forEach(inp => {
                paramValues[`query_${inp.dataset.key}`] = inp.value;
            });

            modal.querySelectorAll('.header-input').forEach(inp => {
                paramValues[`header_${inp.dataset.key}`] = inp.value;
            });

            modal.querySelectorAll('.body-field-input').forEach(inp => {
                paramValues[`body_${inp.dataset.key}`] = inp.value;
            });

            const rawBodyInput = modal.querySelector('.body-raw-input');
            if (rawBodyInput) {
                paramValues.body_raw = rawBodyInput.value;
            }

            const result = await executeApi(apiConfig, env, paramValues);

            btn.disabled = false;
            btn.textContent = 'Execute';

            const responseMeta = modal.querySelector('.response-meta');
            const responseBody = modal.querySelector('.response-body');

            if (result.error) {
                responseMeta.innerHTML = `<span class="error">Error: ${escapeHtml(result.error)}</span>`;
                responseBody.textContent = '';
            } else {
                const statusClass = result.status >= 200 && result.status < 300 ? 'success' : 'error';
                responseMeta.innerHTML = `
                    <span class="${statusClass}">Status: ${result.status} ${result.statusText || ''}</span>
                    <span>Duration: ${result.duration}ms</span>
                `;

                try {
                    const json = JSON.parse(result.body);
                    responseBody.textContent = JSON.stringify(json, null, 2);
                } catch {
                    responseBody.textContent = result.body;
                }
            }
        });
    }

    function showApiQuickMenu(anchorEl, appName, apis) {
        const existingMenu = document.querySelector('.api-quick-menu');
        if (existingMenu) existingMenu.remove();

        const menu = document.createElement('div');
        menu.className = 'api-quick-menu';
        menu.innerHTML = `
            <div class="api-quick-menu-header">
                <span>${escapeHtml(appName)}</span>
                <button class="config-btn" title="Configure APIs">Configure</button>
            </div>
            <div class="api-quick-menu-list">
                ${apis.map((api, idx) => `
                    <button class="api-quick-item" data-idx="${idx}">
                        <span class="api-method-badge ${api.method}">${api.method}</span>
                        <span class="api-name">${escapeHtml(api.name)}</span>
                    </button>
                `).join('')}
            </div>
        `;

        const rect = anchorEl.getBoundingClientRect();
        menu.style.position = 'fixed';
        menu.style.left = `${rect.left}px`;
        menu.style.top = `${rect.bottom + 4}px`;
        menu.style.zIndex = '10000';

        document.body.appendChild(menu);

        menu.querySelector('.config-btn').addEventListener('click', () => {
            menu.remove();
            showApiConfigModal(appName);
        });

        menu.querySelectorAll('.api-quick-item').forEach(item => {
            item.addEventListener('click', () => {
                const idx = parseInt(item.dataset.idx);
                menu.remove();
                showApiExecuteModal(appName, apis[idx]);
            });
        });

        setTimeout(() => {
            document.addEventListener('click', function closeMenu(e) {
                if (!menu.contains(e.target) && !anchorEl.contains(e.target)) {
                    menu.remove();
                    document.removeEventListener('click', closeMenu);
                }
            });
        }, 0);
    }

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function init() {
        document.addEventListener('click', async (e) => {
            const btn = e.target.closest('.app-api-btn');
            if (!btn) return;

            const appName = btn.dataset.appName;
            if (!appName) return;

            e.stopPropagation();

            const config = await loadAppApiConfig(appName);
            if (config.apis && config.apis.length > 0) {
                showApiQuickMenu(btn, appName, config.apis);
            } else {
                showApiConfigModal(appName);
            }
        });
    }

    window.SMD2_AppApiManager = {
        init,
        showApiConfigModal,
        showApiExecuteModal,
        loadAppApiConfig,
        saveAppApiConfig,
        executeApi
    };

})(window);
