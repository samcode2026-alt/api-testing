/**
 * Data Loader - Load configuration data from JSON files.
 *
 * This script loads all configuration data (clients, envs, users, queries)
 * from JSON files and initializes the application once data is ready.
 *
 * Usage in HTML:
 *   <script src="scripts/data-loader.js"></script>
 *   <!-- App scripts will be loaded and initialized after data is ready -->
 */

(function() {
    'use strict';

    const DATA_BASE_PATH = 'data';
    const ENVIRONMENTS = ['local', 'dev', 'qa', 'uat'];

    /**
     * Fetch JSON data for a specific category and environment
     */
    async function fetchEnvData(category, env) {
        try {
            const response = await fetch(`${DATA_BASE_PATH}/${category}/${env}.json`);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            return await response.json();
        } catch (err) {
            console.warn(`Failed to load ${category}/${env}.json: ${err.message}`);
            return null;
        }
    }

    /**
     * Fetch a single JSON file
     */
    async function fetchJsonFile(path) {
        try {
            const response = await fetch(path);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            return await response.json();
        } catch (err) {
            console.warn(`Failed to load ${path}: ${err.message}`);
            return null;
        }
    }

    /**
     * Load all data for a category (clients, envs, or users)
     */
    async function loadCategory(category) {
        const data = {};
        const promises = ENVIRONMENTS.map(async env => {
            const envData = await fetchEnvData(category, env);
            if (envData !== null) {
                data[env] = envData;
            }
        });
        await Promise.all(promises);
        return data;
    }

    /**
     * Load all configuration data from JSON files
     */
    window.loadAllData = async function() {
        console.log('Loading data from JSON files...');

        // Load all categories in parallel
        const [clients, envs, users, queries] = await Promise.all([
            loadCategory('clients'),
            loadCategory('envs'),
            loadCategory('users'),
            fetchJsonFile(`${DATA_BASE_PATH}/queries/queries.json`)
        ]);

        // Set global variables
        if (Object.keys(clients).length > 0) {
            window.SMD2_CLIENTS = clients;
            console.log('  Loaded clients:', Object.keys(clients).join(', '));
        }

        if (Object.keys(envs).length > 0) {
            window.SMD2_ENVS = envs;
            console.log('  Loaded envs:', Object.keys(envs).join(', '));
        }

        if (Object.keys(users).length > 0) {
            window.SMD2_USERS = users;
            console.log('  Loaded users:', Object.keys(users).join(', '));
        }

        if (queries && Array.isArray(queries)) {
            window.SMD2_QUERIES = queries;
            console.log('  Loaded queries:', queries.length, 'groups');
        }

        console.log('Data loading complete.');

        return {
            clients: window.SMD2_CLIENTS || {},
            envs: window.SMD2_ENVS || {},
            users: window.SMD2_USERS || {},
            queries: window.SMD2_QUERIES || []
        };
    };

    /**
     * Check if JSON data is available (for conditional loading)
     */
    window.checkJsonDataAvailable = async function() {
        try {
            const response = await fetch(`${DATA_BASE_PATH}/envs/dev.json`, { method: 'HEAD' });
            return response.ok;
        } catch {
            return false;
        }
    };

    // Auto-load data when script is loaded
    window.dataLoadPromise = window.loadAllData();
})();
