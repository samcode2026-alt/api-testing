#!/usr/bin/env node

/**
 * Extract data from *.js configuration files into environment-specific JSON files.
 *
 * Usage: node extract-data.js
 *
 * This script reads clients.js, envs.js, and users.js and creates:
 *   - data/clients/{env}.json for each environment
 *   - data/envs/{env}.json for each environment
 *   - data/users/{env}.json for each environment
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const rootDir = path.join(__dirname, '..');
const dataDir = path.join(rootDir, 'data');

// Create data directories
['clients', 'envs', 'users', 'queries'].forEach(dir => {
    const dirPath = path.join(dataDir, dir);
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }
});

// Mock window object for script evaluation
const mockWindow = {};

// Helper to evaluate a JS file that sets window.* properties
function loadJsConfig(filename) {
    const filePath = path.join(rootDir, filename);
    if (!fs.existsSync(filePath)) {
        console.log(`  Skipping ${filename} (not found)`);
        return null;
    }

    const code = fs.readFileSync(filePath, 'utf-8');
    const context = { window: mockWindow };
    vm.createContext(context);

    try {
        vm.runInContext(code, context);
        return context.window;
    } catch (err) {
        console.error(`  Error parsing ${filename}: ${err.message}`);
        return null;
    }
}

console.log('Extracting configuration data to JSON files...\n');

// Load clients.js
console.log('Processing clients.js...');
loadJsConfig('clients.js');
if (mockWindow.SMD2_CLIENTS) {
    Object.entries(mockWindow.SMD2_CLIENTS).forEach(([env, clients]) => {
        const outPath = path.join(dataDir, 'clients', `${env}.json`);
        fs.writeFileSync(outPath, JSON.stringify(clients, null, 2));
        console.log(`  Created ${outPath} (${clients.length} clients)`);
    });
}

// Load envs.js
console.log('\nProcessing envs.js...');
loadJsConfig('envs.js');
if (mockWindow.SMD2_ENVS) {
    Object.entries(mockWindow.SMD2_ENVS).forEach(([env, config]) => {
        const outPath = path.join(dataDir, 'envs', `${env}.json`);
        fs.writeFileSync(outPath, JSON.stringify(config, null, 2));
        console.log(`  Created ${outPath}`);
    });
}

// Load users.js
console.log('\nProcessing users.js...');
loadJsConfig('users.js');
if (mockWindow.SMD2_USERS) {
    Object.entries(mockWindow.SMD2_USERS).forEach(([env, users]) => {
        const outPath = path.join(dataDir, 'users', `${env}.json`);
        fs.writeFileSync(outPath, JSON.stringify(users, null, 2));
        console.log(`  Created ${outPath}`);
    });
}

// Load queries.js and all queries_*.js files
console.log('\nProcessing queries files...');
const queryFiles = ['queries.js', 'queries_smd.js', 'queries_teradata.js', 'queries_salesforce.js', 'queries_salesforce_srvc.js'];
const allQueries = [];

queryFiles.forEach(file => {
    loadJsConfig(file);
});

if (mockWindow.SMD2_QUERIES && Array.isArray(mockWindow.SMD2_QUERIES)) {
    const outPath = path.join(dataDir, 'queries', 'queries.json');
    fs.writeFileSync(outPath, JSON.stringify(mockWindow.SMD2_QUERIES, null, 2));
    console.log(`  Created ${outPath} (${mockWindow.SMD2_QUERIES.length} query groups)`);
}

console.log('\nExtraction complete!');
console.log(`Data files written to: ${dataDir}`);
