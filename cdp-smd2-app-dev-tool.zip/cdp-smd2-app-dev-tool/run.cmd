set NODE_OPTIONS=--openssl-legacy-provider
set P12_FILE=config/certs/smdtestcert.comp.pge.com.p12
set P12_PASS=smdtestcert
node server.js
