// Server-side configuration for SMD2 Admin
// This file contains environment-specific configuration that should not be exposed to the client

const path = require('path');
const fs = require('fs');

const CONFIG_DIR = path.join(__dirname);

// Environment configuration
const ENV_CONFIG = {
    dev: {
        name: 'Development',
        batchBase: 'https://dev-batch.pge.com',
        healthCheckBase: 'https://dev-rtf.pge.com',
        mulesoftApi: 'https://anypoint.mulesoft.com'
    },
    qa: {
        name: 'QA',
        batchBase: 'https://qa-batch.pge.com',
        healthCheckBase: 'https://qa-rtf.pge.com',
        mulesoftApi: 'https://anypoint.mulesoft.com'
    },
    uat: {
        name: 'UAT',
        batchBase: 'https://uat-batch.pge.com',
        healthCheckBase: 'https://uat-rtf.pge.com',
        mulesoftApi: 'https://anypoint.mulesoft.com'
    },
    prod: {
        name: 'Production',
        batchBase: 'https://batch.pge.com',
        healthCheckBase: 'https://rtf.pge.com',
        mulesoftApi: 'https://anypoint.mulesoft.com'
    }
};

// Load Anypoint/Mulesoft config for an environment
function loadMulesoftConfig(env) {
    const configFile = path.join(CONFIG_DIR, 'anypoint', `${env}.yaml`);
    if (fs.existsSync(configFile)) {
        const yaml = require('yaml');
        const content = fs.readFileSync(configFile, 'utf8');
        return yaml.parse(content);
    }
    return null;
}

// Get environment config with optional Mulesoft overlay
function getEnvConfig(env) {
    const base = ENV_CONFIG[env] || ENV_CONFIG.dev;
    const muleConfig = loadMulesoftConfig(env);

    if (muleConfig && muleConfig.mule) {
        return {
            ...base,
            mulesoft: {
                accessToken: muleConfig.mule.access_token || '',
                orgId: muleConfig.mule.org_id || '',
                envId: muleConfig.mule.env_id || ''
            }
        };
    }

    return base;
}

module.exports = {
    ENV_CONFIG,
    getEnvConfig,
    loadMulesoftConfig,
    CONFIG_DIR
};
