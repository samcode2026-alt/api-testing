// Health Check configuration for SMD2 Admin
// Contains health check credentials and endpoint configuration per environment

const HEALTHCHECK_CONFIG = {
    dev: {
        username: process.env.HEALTHCHECK_DEV_USER || 'healthcheck',
        password: process.env.HEALTHCHECK_DEV_PASS || '',
        endpoints: {
            default: '/api/health-check',
            liveness: '/api/liveness',
            readiness: '/api/readiness'
        },
        timeout: 10000
    },
    qa: {
        username: process.env.HEALTHCHECK_QA_USER || 'healthcheck',
        password: process.env.HEALTHCHECK_QA_PASS || '',
        endpoints: {
            default: '/api/health-check',
            liveness: '/api/liveness',
            readiness: '/api/readiness'
        },
        timeout: 10000
    },
    uat: {
        username: process.env.HEALTHCHECK_UAT_USER || 'healthcheck',
        password: process.env.HEALTHCHECK_UAT_PASS || '',
        endpoints: {
            default: '/api/health-check',
            liveness: '/api/liveness',
            readiness: '/api/readiness'
        },
        timeout: 10000
    },
    prod: {
        username: process.env.HEALTHCHECK_PROD_USER || 'healthcheck',
        password: process.env.HEALTHCHECK_PROD_PASS || '',
        endpoints: {
            default: '/api/health-check',
            liveness: '/api/liveness',
            readiness: '/api/readiness'
        },
        timeout: 15000
    }
};

// Get health check config for an environment
function getHealthCheckConfig(env) {
    return HEALTHCHECK_CONFIG[env] || HEALTHCHECK_CONFIG.dev;
}

// Build basic auth string for health check requests
function getHealthCheckAuth(env) {
    const config = getHealthCheckConfig(env);
    if (config.username && config.password) {
        return `${config.username}:${config.password}`;
    }
    return null;
}

module.exports = {
    HEALTHCHECK_CONFIG,
    getHealthCheckConfig,
    getHealthCheckAuth
};
