# SMD2 Testing App

A static file server with HTTPS support for serving the SMD2 testing dashboard.

## Features

- HTTPS server with self-signed SSL certificate
- Serves static files (HTML, CSS, JS, images)
- Default page: `smd2.html`

## Prerequisites

- Node.js (v12 or higher)

## Quick Start

1. Start the server:
   ```bash
   . ./run.sh
   ```
Windows
   ```bash
   run.cmd
   ```

2. Open in browser:
   ```
   https://localhost:3443/
   ```

3. Accept the self-signed certificate warning in your browser.

## Custom Port

Set the `PORT` environment variable:
```bash
PORT=8443 node server.js
```

## Using P12/PFX Certificate

To use a P12 (PKCS#12) certificate instead of PEM files:
```bash
P12_FILE=path/to/cert.p12 P12_PASS=yourpassword node server.js
```

Environment variables:
- `P12_FILE` - Path to P12/PFX file (absolute or relative to project)
- `P12_PASS` - Password for the P12 file (optional if no password)

## Regenerate SSL Certificate

If the certificate expires (valid for 365 days):
```bash
openssl req -x509 -newkey rsa:2048 -keyout certs/key.pem -out certs/cert.pem -days 365 -nodes -subj "/CN=localhost"
```

## Files

- `server.js` - HTTPS server
- `certs/` - SSL certificate and key
- `smd2.html` - Main dashboard
- `smd.css` - Styles
- `*.js` - Data and configuration files
