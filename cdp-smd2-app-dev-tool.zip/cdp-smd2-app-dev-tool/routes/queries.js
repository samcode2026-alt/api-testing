// Queries route handlers for SMD2 Admin
const fs = require('fs');
const path = require('path');

function handlePostQueries(req, res, body, dataDir) {
    try {
        const { queries } = JSON.parse(body);

        if (!queries || !Array.isArray(queries)) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing queries array' }));
            return;
        }

        const queriesDir = path.join(dataDir, 'queries');
        const queriesFile = path.join(queriesDir, 'queries.json');

        if (!fs.existsSync(queriesDir)) {
            fs.mkdirSync(queriesDir, { recursive: true });
        }

        fs.writeFileSync(queriesFile, JSON.stringify(queries, null, 2));
        console.log(`[QUERIES] Saved ${queries.length} query tabs to queries.json`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, count: queries.length }));
    } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

module.exports = { handlePostQueries };
