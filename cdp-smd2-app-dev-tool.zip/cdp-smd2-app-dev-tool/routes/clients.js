// Clients route handlers for SMD2 Admin
const fs = require('fs');
const path = require('path');

function handleImportClients(req, res, body, dataDir) {
    try {
        const { env, clients, mode } = JSON.parse(body);

        if (!env || !clients || !Array.isArray(clients)) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing env or clients array' }));
            return;
        }

        const clientsDir = path.join(dataDir, 'clients');
        const clientsFile = path.join(clientsDir, `${env}.json`);

        if (!fs.existsSync(clientsDir)) {
            fs.mkdirSync(clientsDir, { recursive: true });
        }

        let finalData;
        if (mode === 'replace') {
            finalData = clients;
        } else {
            let existingData = [];
            if (fs.existsSync(clientsFile)) {
                existingData = JSON.parse(fs.readFileSync(clientsFile, 'utf8'));
            }
            const clientMap = new Map(existingData.map(c => [c.client_id, c]));
            clients.forEach(c => clientMap.set(c.client_id, c));
            finalData = Array.from(clientMap.values());
        }

        fs.writeFileSync(clientsFile, JSON.stringify(finalData, null, 2));
        console.log(`[CLIENTS] Imported ${clients.length} clients to ${env}.json (mode: ${mode})`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, count: clients.length, total: finalData.length }));
    } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

module.exports = { handleImportClients };
