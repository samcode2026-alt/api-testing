// Subscription route handlers for SMD2 Admin
const fs = require('fs');
const path = require('path');

function handleGetSubscription(req, res, dataDir) {
    const urlParts = req.url.split('/');
    const env = urlParts[3];
    const subscriptionId = urlParts[4];

    if (!env) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing env parameter' }));
        return;
    }

    const subscriptionsFile = path.join(dataDir, 'subscriptions', `${env}.json`);

    try {
        if (fs.existsSync(subscriptionsFile)) {
            const data = JSON.parse(fs.readFileSync(subscriptionsFile, 'utf8'));
            if (subscriptionId) {
                const subscription = data.find(s => s.subscription_id === subscriptionId || s.SubscriptionID === subscriptionId);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(subscription || null));
            } else {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(data));
            }
        } else {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(subscriptionId ? null : []));
        }
    } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

function handlePostSubscription(req, res, body, dataDir) {
    try {
        const { env, subscription_id, refresh_token, access_token, client_access_token, ...otherParams } = JSON.parse(body);

        if (!env || !subscription_id) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing env or subscription_id' }));
            return;
        }

        const subscriptionsDir = path.join(dataDir, 'subscriptions');
        const subscriptionsFile = path.join(subscriptionsDir, `${env}.json`);

        if (!fs.existsSync(subscriptionsDir)) {
            fs.mkdirSync(subscriptionsDir, { recursive: true });
        }

        let data = [];
        if (fs.existsSync(subscriptionsFile)) {
            data = JSON.parse(fs.readFileSync(subscriptionsFile, 'utf8'));
        }

        const existingIdx = data.findIndex(s => s.subscription_id === subscription_id || s.SubscriptionID === subscription_id);
        const subscriptionData = {
            subscription_id,
            ...(refresh_token && { refresh_token }),
            ...(access_token && { access_token }),
            ...(client_access_token && { client_access_token }),
            ...otherParams,
            updated_at: new Date().toISOString()
        };

        if (existingIdx >= 0) {
            data[existingIdx] = { ...data[existingIdx], ...subscriptionData };
        } else {
            data.push(subscriptionData);
        }

        fs.writeFileSync(subscriptionsFile, JSON.stringify(data, null, 4));
        console.log(`[SUBSCRIPTION] Saved subscription ${subscription_id} to ${env}.json`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, subscription: subscriptionData }));
    } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

module.exports = { handleGetSubscription, handlePostSubscription };
