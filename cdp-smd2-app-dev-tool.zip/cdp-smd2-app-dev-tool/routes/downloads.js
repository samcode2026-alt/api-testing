// Downloads route handler for fetching async API results and saving as gzip
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { URL } = require('url');

const DOWNLOADS_DIR = 'data/downloads';

function ensureDownloadsDir(baseDir) {
    const downloadsPath = path.join(baseDir, '..', DOWNLOADS_DIR);
    if (!fs.existsSync(downloadsPath)) {
        fs.mkdirSync(downloadsPath, { recursive: true });
    }
    return downloadsPath;
}

function handleFetchResults(req, res, body, DATA_DIR, clientCertOptions, LOG_HEADERS) {
    let parsed;
    try {
        parsed = JSON.parse(body);
    } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON body' }));
        return;
    }

    const { correlationIds, baseUrl, token } = parsed;

    if (!correlationIds || !Array.isArray(correlationIds) || correlationIds.length === 0) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing or invalid correlationIds array' }));
        return;
    }

    if (!baseUrl) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing baseUrl' }));
        return;
    }

    const downloadsPath = ensureDownloadsDir(DATA_DIR);
    const results = [];

    let completedCount = 0;

    correlationIds.forEach(corrId => {
        const downloadUrl = baseUrl + (baseUrl.includes('?') ? '&' : '?') + `correlationID=${corrId}`;

        let parsedUrl;
        try {
            parsedUrl = new URL(downloadUrl);
        } catch (e) {
            results.push({
                correlationId: corrId,
                success: false,
                error: 'Invalid URL'
            });
            completedCount++;
            checkComplete();
            return;
        }

        const reqHeaders = { 'Accept': 'application/atom+xml,application/json,*/*' };
        if (token) reqHeaders['Authorization'] = `Bearer ${token}`;

        const proto = parsedUrl.protocol === 'https:' ? https : http;
        const reqOptions = {
            hostname: parsedUrl.hostname,
            port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
            path: parsedUrl.pathname + parsedUrl.search,
            method: 'GET',
            headers: reqHeaders,
            rejectUnauthorized: false
        };

        if (parsedUrl.protocol === 'https:' && clientCertOptions) {
            reqOptions.pfx = clientCertOptions.pfx;
            reqOptions.passphrase = clientCertOptions.passphrase;
        }

        const t0 = Date.now();

        if (LOG_HEADERS) {
            console.log(`[DOWNLOAD] Fetching correlationID: ${corrId}`);
        }

        const proxyReq = proto.request(reqOptions, proxyRes => {
            const chunks = [];
            proxyRes.on('data', chunk => chunks.push(chunk));
            proxyRes.on('end', () => {
                const duration = Date.now() - t0;
                const responseBuffer = Buffer.concat(chunks);

                if (proxyRes.statusCode >= 200 && proxyRes.statusCode < 300) {
                    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                    const filename = `${corrId}_${timestamp}.xml.gzip`;
                    const filepath = path.join(downloadsPath, filename);

                    zlib.gzip(responseBuffer, (err, compressed) => {
                        if (err) {
                            results.push({
                                correlationId: corrId,
                                success: false,
                                error: 'Compression failed: ' + err.message,
                                status: proxyRes.statusCode,
                                duration
                            });
                        } else {
                            fs.writeFile(filepath, compressed, (writeErr) => {
                                if (writeErr) {
                                    results.push({
                                        correlationId: corrId,
                                        success: false,
                                        error: 'Write failed: ' + writeErr.message,
                                        status: proxyRes.statusCode,
                                        duration
                                    });
                                } else {
                                    if (LOG_HEADERS) {
                                        console.log(`[DOWNLOAD] Saved: ${filename} (${compressed.length} bytes, ${duration}ms)`);
                                    }
                                    results.push({
                                        correlationId: corrId,
                                        success: true,
                                        filename,
                                        filepath: `${DOWNLOADS_DIR}/${filename}`,
                                        size: compressed.length,
                                        originalSize: responseBuffer.length,
                                        status: proxyRes.statusCode,
                                        duration
                                    });
                                }
                                completedCount++;
                                checkComplete();
                            });
                        }
                    });
                } else {
                    results.push({
                        correlationId: corrId,
                        success: false,
                        error: `HTTP ${proxyRes.statusCode} ${proxyRes.statusMessage}`,
                        status: proxyRes.statusCode,
                        duration
                    });
                    completedCount++;
                    checkComplete();
                }
            });
        });

        proxyReq.on('error', err => {
            results.push({
                correlationId: corrId,
                success: false,
                error: err.message
            });
            completedCount++;
            checkComplete();
        });

        proxyReq.end();
    });

    function checkComplete() {
        if (completedCount === correlationIds.length) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                success: true,
                results,
                downloadDir: DOWNLOADS_DIR
            }));
        }
    }
}

function handleViewXml(req, res, DATA_DIR) {
    const urlParts = req.url.split('/');
    const filename = decodeURIComponent(urlParts[urlParts.length - 1]);

    if (!filename || !filename.endsWith('.xml.gz')) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid filename' }));
        return;
    }

    const filepath = path.join(DATA_DIR, '..', DOWNLOADS_DIR, filename);

    if (!fs.existsSync(filepath)) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'File not found' }));
        return;
    }

    fs.readFile(filepath, (err, compressedData) => {
        if (err) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Failed to read file: ' + err.message }));
            return;
        }

        zlib.gunzip(compressedData, (gunzipErr, decompressed) => {
            if (gunzipErr) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Failed to decompress: ' + gunzipErr.message }));
                return;
            }

            res.writeHead(200, {
                'Content-Type': 'application/xml',
                'Content-Disposition': `inline; filename="${filename.replace('.gz', '')}"`,
                'Access-Control-Allow-Origin': '*'
            });
            res.end(decompressed);
        });
    });
}

function handleListDownloads(req, res, DATA_DIR) {
    const downloadsPath = path.join(DATA_DIR, '..', DOWNLOADS_DIR);

    if (!fs.existsSync(downloadsPath)) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ files: [] }));
        return;
    }

    fs.readdir(downloadsPath, (err, files) => {
        if (err) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Failed to list files: ' + err.message }));
            return;
        }

        const gzFiles = files
            .filter(f => f.endsWith('.xml.gz'))
            .map(f => {
                const stats = fs.statSync(path.join(downloadsPath, f));
                const corrId = f.split('_')[0];
                return {
                    filename: f,
                    correlationId: corrId,
                    size: stats.size,
                    created: stats.mtime
                };
            })
            .sort((a, b) => new Date(b.created) - new Date(a.created));

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ files: gzFiles }));
    });
}

module.exports = { handleFetchResults, handleViewXml, handleListDownloads };
