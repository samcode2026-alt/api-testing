// Mulesoft route handlers for SMD2 Admin
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

function handleGetMulesoftConfig(req, res, dataDir) {
    const env = req.url.split('/')[4];
    if (!env) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing env parameter' }));
        return;
    }

    const envFile = path.join(dataDir, 'envs', `${env}.json`);
    try {
        if (fs.existsSync(envFile)) {
            const data = JSON.parse(fs.readFileSync(envFile, 'utf8'));
            const muleConfig = data.mulesoft || { orgId: '', envId: '', accessToken: '' };
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(muleConfig));
        } else {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ orgId: '', envId: '', accessToken: '' }));
        }
    } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

function handlePostMulesoftConfig(req, res, body, dataDir) {
    try {
        const { env, orgId, envId, accessToken } = JSON.parse(body);

        if (!env) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing env parameter' }));
            return;
        }

        const envsDir = path.join(dataDir, 'envs');
        const envFile = path.join(envsDir, `${env}.json`);

        if (!fs.existsSync(envsDir)) {
            fs.mkdirSync(envsDir, { recursive: true });
        }

        let envData = {};
        if (fs.existsSync(envFile)) {
            envData = JSON.parse(fs.readFileSync(envFile, 'utf8'));
        }

        envData.mulesoft = {
            orgId: orgId || '',
            envId: envId || '',
            accessToken: accessToken || ''
        };

        fs.writeFileSync(envFile, JSON.stringify(envData, null, 2));
        console.log(`[MULESOFT] Saved config for ${env}`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
    } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

function handleMulesoftProxy(req, res, body, dataDir, LOG_HEADERS) {
    let parsed;
    try { parsed = JSON.parse(body); } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON body' }));
        return;
    }

    const { env, endpoint, accessToken: providedToken } = parsed;

    if (!env || !endpoint) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing env or endpoint' }));
        return;
    }

    let token = providedToken;
    let orgId, envId;

    const envFile = path.join(dataDir, 'envs', `${env}.json`);
    try {
        if (fs.existsSync(envFile)) {
            const envData = JSON.parse(fs.readFileSync(envFile, 'utf8'));
            const muleConfig = envData.mulesoft || {};
            if (!token) token = muleConfig.accessToken;
            orgId = muleConfig.orgId;
            envId = muleConfig.envId;
        }
    } catch (e) {
        console.error('Failed to load mulesoft config:', e.message);
    }

    if (!token) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'No access token configured for this environment' }));
        return;
    }

    let targetUrl = endpoint;
    if (!endpoint.startsWith('http')) {
        targetUrl = `https://anypoint.mulesoft.com${endpoint}`;
    }

    targetUrl = targetUrl.replace('{orgId}', orgId || '').replace('{envId}', envId || '');

    const parsedUrl = new URL(targetUrl);
    const reqHeaders = {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    };

    const startTime = Date.now();

    if (LOG_HEADERS) {
        console.log('\n══════════════════════════════════════════════════════════════');
        console.log(`[MULESOFT PROXY] GET ${targetUrl}`);
        console.log('══════════════════════════════════════════════════════════════');
    }

    const proxyReq = https.request({
        hostname: parsedUrl.hostname,
        port: 443,
        path: parsedUrl.pathname + parsedUrl.search,
        method: 'GET',
        headers: reqHeaders,
        rejectUnauthorized: false
    }, proxyRes => {
        let respBody = '';
        proxyRes.setEncoding('utf8');
        proxyRes.on('data', chunk => { respBody += chunk; });
        proxyRes.on('end', () => {
            const duration = Date.now() - startTime;
            if (LOG_HEADERS) {
                console.log(`[MULESOFT RESPONSE] Status: ${proxyRes.statusCode} (${duration}ms)`);
            }

            res.writeHead(200, {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            });
            res.end(JSON.stringify({
                status: proxyRes.statusCode,
                statusText: proxyRes.statusMessage,
                body: respBody,
                orgId,
                envId
            }));
        });
    });

    proxyReq.on('error', err => {
        if (LOG_HEADERS) {
            console.log(`[MULESOFT ERROR] ${err.message}`);
        }
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    });

    proxyReq.end();
}

module.exports = { handleGetMulesoftConfig, handlePostMulesoftConfig, handleMulesoftProxy };
