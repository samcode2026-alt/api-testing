// Proxy route handler for SMD2 Admin
const https = require('https');
const http = require('http');
const { URL } = require('url');

function createProxyHandler(clientCertOptions, LOG_HEADERS) {
    return function handleProxy(req, res, body) {
        let parsed;
        try { parsed = JSON.parse(body); } catch (e) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Invalid JSON body' }));
            return;
        }

        const { method = 'GET', url: targetUrl, token, basicAuth, formBody, contentType, noCert } = parsed;

        if (!targetUrl) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing url field' }));
            return;
        }

        let parsedUrl;
        try { parsedUrl = new URL(targetUrl); } catch (e) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Invalid target URL' }));
            return;
        }

        const reqHeaders = { 'Accept': 'application/atom+xml,application/json,*/*' };
        if (token) reqHeaders['Authorization'] = `Bearer ${token}`;
        if (basicAuth) reqHeaders['Authorization'] = `Basic ${Buffer.from(basicAuth).toString('base64')}`;
        if (contentType) reqHeaders['Content-Type'] = contentType;
        if (formBody) reqHeaders['Content-Length'] = Buffer.byteLength(formBody);

        const proto = parsedUrl.protocol === 'https:' ? https : http;
        const reqOptions = {
            hostname: parsedUrl.hostname,
            port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
            path: parsedUrl.pathname + parsedUrl.search,
            method: method.toUpperCase(),
            headers: reqHeaders,
            rejectUnauthorized: false
        };

        if (parsedUrl.protocol === 'https:' && clientCertOptions && !noCert) {
            reqOptions.pfx = clientCertOptions.pfx;
            reqOptions.passphrase = clientCertOptions.passphrase;
        }

        const startTime = new Date();
        const t0 = Date.now();

        if (LOG_HEADERS) {
            console.log('\n══════════════════════════════════════════════════════════════');
            console.log(`[PROXY REQUEST] ${method.toUpperCase()} ${targetUrl}`);
            console.log(`▶ Start: ${startTime.toLocaleTimeString()}.${startTime.getMilliseconds().toString().padStart(3, '0')}`);
            console.log('──────────────────────────────────────────────────────────────');
            console.log('Request Headers:');
            Object.entries(reqHeaders).forEach(([k, v]) => {
                let displayVal = v;
                if (k.toLowerCase() === 'authorization') {
                    // Show last 10 characters of the token for debugging
                    const parts = v.split(' ');
                    const authType = parts[0] || 'Bearer';
                    const token = parts[1] || '';
                    const last10 = token.length > 10 ? '...' + token.slice(-10) : token;
                    displayVal = `${authType} ${last10}`;
                }
                console.log(`  ${k}: ${displayVal}`);
            });
            if (clientCertOptions && !noCert) {
                console.log('  [Client Certificate: ATTACHED]');
            }
            if (formBody) {
                console.log('Request Body (form):');
                const maskedBody = formBody.replace(/(client_secret|code|refresh_token|token)=([^&]+)/gi, '$1=[REDACTED]');
                console.log(`  ${maskedBody}`);
            }
        }

        const proxyReq = proto.request(reqOptions, proxyRes => {
            let respBody = '';
            proxyRes.setEncoding('utf8');
            proxyRes.on('data', chunk => { respBody += chunk; });
            proxyRes.on('end', () => {
                const endTime = new Date();
                const duration = Date.now() - t0;

                if (LOG_HEADERS) {
                    console.log('──────────────────────────────────────────────────────────────');
                    console.log(`[PROXY RESPONSE] Status: ${proxyRes.statusCode} ${proxyRes.statusMessage}`);
                    console.log(`◀ End: ${endTime.toLocaleTimeString()}.${endTime.getMilliseconds().toString().padStart(3, '0')}`);
                    console.log(`⏱ Duration: ${duration} ms`);
                    console.log('Response Headers:');
                    Object.entries(proxyRes.headers).forEach(([k, v]) => {
                        console.log(`  ${k}: ${v}`);
                    });
                    console.log('══════════════════════════════════════════════════════════════\n');
                }

                res.writeHead(200, {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                });
                res.end(JSON.stringify({
                    status: proxyRes.statusCode,
                    statusText: proxyRes.statusMessage,
                    headers: proxyRes.headers,
                    body: respBody
                }));
            });
        });

        proxyReq.on('error', err => {
            const endTime = new Date();
            const duration = Date.now() - t0;
            if (LOG_HEADERS) {
                console.log('──────────────────────────────────────────────────────────────');
                console.log(`[PROXY ERROR] ${err.message}`);
                console.log(`◀ End: ${endTime.toLocaleTimeString()}.${endTime.getMilliseconds().toString().padStart(3, '0')}`);
                console.log(`⏱ Duration: ${duration} ms`);
                console.log('══════════════════════════════════════════════════════════════\n');
            }
            res.writeHead(502, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: err.message }));
        });

        if (formBody) proxyReq.write(formBody);
        proxyReq.end();
    };
}

module.exports = { createProxyHandler };
