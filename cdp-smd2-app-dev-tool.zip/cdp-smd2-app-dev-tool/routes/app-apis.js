// App APIs route handlers for SMD2 Admin
// Provides CRUD operations for per-app API configurations
// and a proxy endpoint for executing configured APIs
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { URL } = require('url');

const APP_APIS_DIR = 'app-apis';

function handleListAppApis(req, res, dataDir) {
    const apisDir = path.join(dataDir, APP_APIS_DIR);

    if (!fs.existsSync(apisDir)) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ apps: [] }));
        return;
    }

    try {
        const files = fs.readdirSync(apisDir).filter(f => f.endsWith('.json'));
        const apps = files.map(f => {
            const data = JSON.parse(fs.readFileSync(path.join(apisDir, f), 'utf8'));
            return {
                appName: data.appName,
                businessGroup: data.businessGroup,
                apiCount: (data.apis || []).length,
                filename: f
            };
        });

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ apps }));
    } catch (err) {
        console.error('[APP-APIS] Error listing apps:', err.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

function handleGetAppApis(req, res, dataDir) {
    const urlParts = req.url.split('/');
    const appName = decodeURIComponent(urlParts[3]);

    if (!appName) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing app name' }));
        return;
    }

    const filepath = path.join(dataDir, APP_APIS_DIR, `${appName}.json`);

    if (!fs.existsSync(filepath)) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ appName, apis: [] }));
        return;
    }

    try {
        const data = JSON.parse(fs.readFileSync(filepath, 'utf8'));
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(data));
    } catch (err) {
        console.error(`[APP-APIS] Error reading config for ${appName}:`, err.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

function handleSaveAppApis(req, res, body, dataDir) {
    const urlParts = req.url.split('/');
    const appName = decodeURIComponent(urlParts[3]);

    if (!appName) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing app name' }));
        return;
    }

    const apisDir = path.join(dataDir, APP_APIS_DIR);

    if (!fs.existsSync(apisDir)) {
        fs.mkdirSync(apisDir, { recursive: true });
    }

    try {
        const data = JSON.parse(body);
        data.appName = appName;

        const filepath = path.join(apisDir, `${appName}.json`);
        fs.writeFileSync(filepath, JSON.stringify(data, null, 2));

        console.log(`[APP-APIS] Saved config for ${appName} (${(data.apis || []).length} APIs)`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
    } catch (err) {
        console.error(`[APP-APIS] Error saving config for ${appName}:`, err.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

function handleSearchAppApis(req, res, dataDir) {
    const urlObj = new URL(req.url, `http://${req.headers.host}`);
    const query = (urlObj.searchParams.get('q') || '').toLowerCase().trim();

    if (!query) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify([]));
        return;
    }

    const apisDir = path.join(dataDir, APP_APIS_DIR);

    if (!fs.existsSync(apisDir)) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify([]));
        return;
    }

    try {
        const files = fs.readdirSync(apisDir).filter(f => f.endsWith('.json'));
        const results = [];

        files.forEach(f => {
            try {
                const data = JSON.parse(fs.readFileSync(path.join(apisDir, f), 'utf8'));
                const appName = data.appName || f.replace('.json', '');

                (data.apis || []).forEach((api, apiIndex) => {
                    const nameMatch = (api.name || '').toLowerCase().includes(query);
                    const endpointMatch = (api.endpoint || '').toLowerCase().includes(query);

                    if (nameMatch || endpointMatch) {
                        results.push({
                            appName,
                            apiIndex,
                            name: api.name || 'Unnamed API',
                            method: api.method || 'GET',
                            endpoint: api.endpoint || '',
                            matchedOn: nameMatch ? 'name' : 'endpoint'
                        });
                    }
                });
            } catch (err) {
                console.error(`[APP-APIS] Error reading ${f}:`, err.message);
            }
        });

        // Sort results: name matches first, then by app name
        results.sort((a, b) => {
            if (a.matchedOn !== b.matchedOn) {
                return a.matchedOn === 'name' ? -1 : 1;
            }
            return a.appName.localeCompare(b.appName);
        });

        console.log(`[APP-APIS] Search "${query}" found ${results.length} APIs`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(results));
    } catch (err) {
        console.error('[APP-APIS] Error searching APIs:', err.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

function handleExecuteAppApi(req, res, body, dataDir, clientCertOptions, LOG_HEADERS) {
    let parsed;
    try {
        parsed = JSON.parse(body);
    } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON body' }));
        return;
    }

    const {
        method = 'GET',
        url: targetUrl,
        headers = {},
        body: requestBody,
        bodyType,
        noCert = false
    } = parsed;

    if (!targetUrl) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing url field' }));
        return;
    }

    let parsedUrl;
    try {
        parsedUrl = new URL(targetUrl);
    } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid target URL' }));
        return;
    }

    const reqHeaders = { ...headers };
    if (!reqHeaders['Accept']) {
        reqHeaders['Accept'] = 'application/json,application/xml,*/*';
    }

    let bodyContent = null;
    if (requestBody && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
        if (bodyType === 'json') {
            bodyContent = typeof requestBody === 'string' ? requestBody : JSON.stringify(requestBody);
            if (!reqHeaders['Content-Type']) {
                reqHeaders['Content-Type'] = 'application/json';
            }
        } else if (bodyType === 'form') {
            bodyContent = new URLSearchParams(requestBody).toString();
            if (!reqHeaders['Content-Type']) {
                reqHeaders['Content-Type'] = 'application/x-www-form-urlencoded';
            }
        } else if (bodyType === 'raw') {
            bodyContent = requestBody;
        } else {
            bodyContent = typeof requestBody === 'string' ? requestBody : JSON.stringify(requestBody);
        }
        reqHeaders['Content-Length'] = Buffer.byteLength(bodyContent);
    }

    const proto = parsedUrl.protocol === 'https:' ? https : http;
    const reqOptions = {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
        path: parsedUrl.pathname + parsedUrl.search,
        method: method.toUpperCase(),
        headers: reqHeaders,
        rejectUnauthorized: false
    };

    if (parsedUrl.protocol === 'https:' && clientCertOptions && !noCert) {
        reqOptions.pfx = clientCertOptions.pfx;
        reqOptions.passphrase = clientCertOptions.passphrase;
    }

    const startTime = Date.now();

    if (LOG_HEADERS) {
        console.log('\n══════════════════════════════════════════════════════════════');
        console.log(`[APP-API PROXY] ${method.toUpperCase()} ${targetUrl}`);
        console.log('──────────────────────────────────────────────────────────────');
        console.log('Request Headers:');
        Object.entries(reqHeaders).forEach(([k, v]) => {
            let displayVal = v;
            if (k.toLowerCase() === 'authorization') {
                const parts = v.split(' ');
                const authType = parts[0] || 'Bearer';
                const token = parts[1] || '';
                const last10 = token.length > 10 ? '...' + token.slice(-10) : token;
                displayVal = `${authType} ${last10}`;
            }
            console.log(`  ${k}: ${displayVal}`);
        });
        if (bodyContent) {
            console.log('Request Body:');
            const displayBody = bodyContent.length > 500 ? bodyContent.substring(0, 500) + '...' : bodyContent;
            console.log(`  ${displayBody}`);
        }
    }

    const proxyReq = proto.request(reqOptions, proxyRes => {
        let respBody = '';
        proxyRes.setEncoding('utf8');
        proxyRes.on('data', chunk => { respBody += chunk; });
        proxyRes.on('end', () => {
            const duration = Date.now() - startTime;

            if (LOG_HEADERS) {
                console.log('──────────────────────────────────────────────────────────────');
                console.log(`[APP-API PROXY] Response: ${proxyRes.statusCode} ${proxyRes.statusMessage} (${duration}ms)`);
                console.log('══════════════════════════════════════════════════════════════\n');
            }

            res.writeHead(200, {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            });
            res.end(JSON.stringify({
                status: proxyRes.statusCode,
                statusText: proxyRes.statusMessage,
                headers: proxyRes.headers,
                body: respBody,
                duration
            }));
        });
    });

    proxyReq.on('error', err => {
        const duration = Date.now() - startTime;
        if (LOG_HEADERS) {
            console.log('──────────────────────────────────────────────────────────────');
            console.log(`[APP-API PROXY] Error: ${err.message} (${duration}ms)`);
            console.log('══════════════════════════════════════════════════════════════\n');
        }
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message, duration }));
    });

    if (bodyContent) proxyReq.write(bodyContent);
    proxyReq.end();
}

module.exports = {
    handleListAppApis,
    handleGetAppApis,
    handleSaveAppApis,
    handleSearchAppApis,
    handleExecuteAppApi
};
