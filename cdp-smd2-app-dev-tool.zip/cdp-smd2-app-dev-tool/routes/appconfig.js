// AppConfig route handlers for SMD2 Admin
// Server-side Mulesoft capacity data fetching with logging and report generation
const https = require('https');
const fs = require('fs');
const path = require('path');

// Convert CPU values (e.g., "500m" -> 0.5)
function convertCpu(value) {
    if (!value || value === 'N/A') return 0;
    value = String(value);
    if (value.endsWith('m')) {
        return parseFloat(value.slice(0, -1)) / 1000;
    }
    return parseFloat(value) || 0;
}

// Convert Memory values (e.g., "512Mi" -> 0.5)
function convertMemory(value) {
    if (!value || value === 'N/A') return 0;
    value = String(value);
    if (value.endsWith('Mi')) {
        return parseFloat(value.slice(0, -2)) / 1024;
    } else if (value.endsWith('Gi')) {
        return parseFloat(value.slice(0, -2));
    } else if (value.endsWith('Ki')) {
        return parseFloat(value.slice(0, -2)) / (1024 * 1024);
    }
    return parseFloat(value) || 0;
}

// Make HTTPS request to Mulesoft API
function mulesoftRequest(url, accessToken) {
    return new Promise((resolve, reject) => {
        const parsedUrl = new URL(url);
        const reqHeaders = {
            'Authorization': `Bearer ${accessToken}`,
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        };

        const startTime = Date.now();
        console.log(`[APPCONFIG API] GET ${url}`);

        const req = https.request({
            hostname: parsedUrl.hostname,
            port: 443,
            path: parsedUrl.pathname + parsedUrl.search,
            method: 'GET',
            headers: reqHeaders,
            rejectUnauthorized: false
        }, res => {
            let body = '';
            res.setEncoding('utf8');
            res.on('data', chunk => { body += chunk; });
            res.on('end', () => {
                const duration = Date.now() - startTime;
                console.log(`[APPCONFIG API] Response: ${res.statusCode} (${duration}ms)`);

                if (res.statusCode >= 200 && res.statusCode < 300) {
                    try {
                        resolve(JSON.parse(body));
                    } catch (e) {
                        reject(new Error(`Invalid JSON response: ${e.message}`));
                    }
                } else {
                    reject(new Error(`API returned ${res.statusCode}: ${body.substring(0, 200)}`));
                }
            });
        });

        req.on('error', err => {
            console.log(`[APPCONFIG API] Error: ${err.message}`);
            reject(err);
        });

        req.end();
    });
}

// Fetch and process Mulesoft capacity data
async function fetchCapacityData(accessToken, orgId, envId, appFilter) {
    const baseUrl = 'https://anypoint.mulesoft.com';
    const deploymentsUrl = `${baseUrl}/amc/application-manager/api/v2/organizations/${orgId}/environments/${envId}/deployments`;

    console.log('\n══════════════════════════════════════════════════════════════');
    console.log('[APPCONFIG] Starting capacity data fetch');
    console.log(`  Org ID: ${orgId}`);
    console.log(`  Env ID: ${envId}`);
    console.log(`  Filter: ${appFilter || '(none)'}`);
    console.log('══════════════════════════════════════════════════════════════');

    const deploymentsData = await mulesoftRequest(deploymentsUrl, accessToken);
    const items = deploymentsData.items || [];

    console.log(`[APPCONFIG] Found ${items.length} total deployments`);

    let filteredItems = items;
    if (appFilter) {
        filteredItems = items.filter(app => app.name && app.name.startsWith(appFilter));
        console.log(`[APPCONFIG] After filter: ${filteredItems.length} apps`);
    }

    const results = [];
    const apiLog = [];

    for (const app of filteredItems) {
        const appId = app.id;
        const detailUrl = `${baseUrl}/amc/application-manager/api/v2/organizations/${orgId}/environments/${envId}/deployments/${appId}`;

        try {
            const detail = await mulesoftRequest(detailUrl, accessToken);

            const target = detail.target || {};
            const replicas = target.replicas || 0;

            const application = detail.application || {};
            const configuration = application.configuration || {};
            const appPropsService = configuration['mule.agent.application.properties.service'] || {};
            const properties = appPropsService.properties || {};
            const apiId = properties['api.id'] || 'N/A';

            const deploymentSettings = target.deploymentSettings || {};
            const resources = deploymentSettings.resources || {};

            const cpu = resources.cpu || {};
            const reservedCpu = convertCpu(cpu.reserved);
            const cpuLimit = convertCpu(cpu.limit);

            const memory = resources.memory || {};
            const memoryGb = convertMemory(memory.reserved);

            const runtimeVersionFull = app.currentRuntimeVersion || 'N/A';
            let runtimeVersion = runtimeVersionFull;
            let jdkVersion = 'N/A';
            if (runtimeVersionFull.includes('-java')) {
                const parts = runtimeVersionFull.split('-java');
                runtimeVersion = parts[0];
                jdkVersion = 'java' + parts[1];
            }

            const result = {
                appName: app.name,
                apiId,
                status: application.status || 'N/A',
                reservedCpu,
                cpuLimit,
                memoryGb,
                replicas: typeof replicas === 'number' ? replicas : 0,
                runtimeVersion,
                jdkVersion
            };

            results.push(result);

            apiLog.push({
                appName: app.name,
                apiId,
                url: detailUrl,
                status: 'success',
                timestamp: new Date().toISOString()
            });
        } catch (err) {
            console.log(`[APPCONFIG] Failed to fetch details for ${app.name}: ${err.message}`);
            apiLog.push({
                appName: app.name,
                url: detailUrl,
                status: 'error',
                error: err.message,
                timestamp: new Date().toISOString()
            });
        }
    }

    // Sort results by suffix then name
    results.sort((a, b) => {
        const suffixA = a.appName.split('-').pop() || '';
        const suffixB = b.appName.split('-').pop() || '';
        if (suffixA !== suffixB) return suffixA.localeCompare(suffixB);
        return a.appName.localeCompare(b.appName);
    });

    // Calculate totals
    const totals = results.reduce((acc, r) => ({
        reservedCpu: acc.reservedCpu + r.reservedCpu,
        cpuLimit: acc.cpuLimit + r.cpuLimit,
        memoryGb: acc.memoryGb + r.memoryGb,
        replicas: acc.replicas + r.replicas
    }), { reservedCpu: 0, cpuLimit: 0, memoryGb: 0, replicas: 0 });

    console.log('\n══════════════════════════════════════════════════════════════');
    console.log('[APPCONFIG] Fetch complete');
    console.log(`  Total Apps: ${results.length}`);
    console.log(`  Total CPU (reserved): ${totals.reservedCpu.toFixed(2)} vCPU`);
    console.log(`  Total Memory: ${totals.memoryGb.toFixed(2)} GB`);
    console.log(`  Total Replicas: ${totals.replicas}`);
    console.log('══════════════════════════════════════════════════════════════\n');

    return {
        results,
        totals,
        apiLog,
        fetchedAt: new Date().toISOString()
    };
}

// Generate report in various formats
function generateReport(data, format = 'json') {
    const { results, totals, fetchedAt } = data;

    if (format === 'csv') {
        const headers = ['App Name', 'API ID', 'Status', 'CPU Reserved (vCPU)', 'CPU Limit (vCPU)', 'Memory (GB)', 'Replicas', 'Runtime', 'JDK'];
        const rows = results.map(r => [
            r.appName, r.apiId, r.status,
            r.reservedCpu.toFixed(2), r.cpuLimit.toFixed(2), r.memoryGb.toFixed(2),
            r.replicas, r.runtimeVersion, r.jdkVersion
        ]);
        rows.push(['TOTAL', '', '', totals.reservedCpu.toFixed(2), totals.cpuLimit.toFixed(2), totals.memoryGb.toFixed(2), totals.replicas, '', '']);

        return [headers, ...rows].map(row => row.join(',')).join('\n');
    }

    if (format === 'markdown') {
        let md = `# Mulesoft Capacity Report\n\n`;
        md += `**Generated:** ${fetchedAt}\n\n`;
        md += `## Summary\n\n`;
        md += `| Metric | Value |\n|--------|-------|\n`;
        md += `| Total Apps | ${results.length} |\n`;
        md += `| Total CPU (reserved) | ${totals.reservedCpu.toFixed(2)} vCPU |\n`;
        md += `| Total Memory | ${totals.memoryGb.toFixed(2)} GB |\n`;
        md += `| Total Replicas | ${totals.replicas} |\n\n`;
        md += `## Applications\n\n`;
        md += `| App Name | API ID | Status | CPU Reserved | CPU Limit | Memory | Replicas | Runtime | JDK |\n`;
        md += `|----------|--------|--------|--------------|-----------|--------|----------|---------|-----|\n`;
        results.forEach(r => {
            md += `| ${r.appName} | ${r.apiId} | ${r.status} | ${r.reservedCpu.toFixed(2)} | ${r.cpuLimit.toFixed(2)} | ${r.memoryGb.toFixed(2)} | ${r.replicas} | ${r.runtimeVersion} | ${r.jdkVersion} |\n`;
        });

        return md;
    }

    return JSON.stringify(data, null, 2);
}

// HTTP handler for fetching capacity
async function handleFetchCapacity(req, res, body, dataDir) {
    try {
        const { env, accessToken, orgId, envId, appFilter } = JSON.parse(body);

        if (!accessToken || !orgId || !envId) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing accessToken, orgId, or envId' }));
            return;
        }

        const data = await fetchCapacityData(accessToken, orgId, envId, appFilter);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, ...data }));
    } catch (err) {
        console.error('[APPCONFIG] Error:', err.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

// HTTP handler for generating report
async function handleGenerateReport(req, res, body, dataDir) {
    try {
        const { env, accessToken, orgId, envId, appFilter, format = 'json' } = JSON.parse(body);

        if (!accessToken || !orgId || !envId) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Missing accessToken, orgId, or envId' }));
            return;
        }

        const data = await fetchCapacityData(accessToken, orgId, envId, appFilter);
        const report = generateReport(data, format);

        const contentTypes = {
            json: 'application/json',
            csv: 'text/csv',
            markdown: 'text/markdown'
        };

        const filename = `mulesoft-capacity-${env || 'report'}-${new Date().toISOString().split('T')[0]}`;
        const extensions = { json: 'json', csv: 'csv', markdown: 'md' };

        res.writeHead(200, {
            'Content-Type': contentTypes[format] || 'application/json',
            'Content-Disposition': `attachment; filename="${filename}.${extensions[format] || 'json'}"`
        });
        res.end(report);
    } catch (err) {
        console.error('[APPCONFIG] Report error:', err.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
    }
}

module.exports = {
    handleFetchCapacity,
    handleGenerateReport,
    fetchCapacityData,
    generateReport
};
