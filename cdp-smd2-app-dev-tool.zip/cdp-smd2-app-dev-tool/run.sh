export NODE_OPTIONS=--openssl-legacy-provider
export P12_FILE=
export P12_PASS=
export PORT=9443
export DOWNLOAD_PATH=../smd_downloads
node server.js
