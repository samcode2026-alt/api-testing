const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

// Route handlers
const { createProxyHandler } = require('./routes/proxy');
const { handleGetSubscription, handlePostSubscription } = require('./routes/subscription');
const { handleGetMulesoftConfig, handlePostMulesoftConfig, handleMulesoftProxy } = require('./routes/mulesoft');
const { handleImportClients } = require('./routes/clients');
const { handlePostQueries } = require('./routes/queries');
const { handleFetchCapacity, handleGenerateReport } = require('./routes/appconfig');
const { handleFetchResults, handleViewXml, handleListDownloads } = require('./routes/downloads');
const { handleListAppApis, handleGetAppApis, handleSaveAppApis, handleSearchAppApis, handleExecuteAppApi } = require('./routes/app-apis');

// Configuration
const PORT = process.env.PORT || 3443;
const P12_FILE = process.env.P12_FILE;
const P12_PASS = process.env.P12_PASS || '';
const LOG_HEADERS = process.env.LOG_HEADERS === 'true' || true;
const DATA_DIR = path.join(__dirname, 'data');

let serverOptions;
let clientCertOptions = null;

if (P12_FILE) {
    const p12Path = path.isAbsolute(P12_FILE) ? P12_FILE : path.join(__dirname, P12_FILE);
    const pfxData = fs.readFileSync(p12Path);
    serverOptions = {
        pfx: pfxData,
        passphrase: P12_PASS
    };
    clientCertOptions = {
        pfx: pfxData,
        passphrase: P12_PASS
    };
    console.log(`Using P12 certificate: ${p12Path}`);
    console.log(`Client cert authentication: ENABLED for GBC API calls`);
} else {
    serverOptions = {
        key: fs.readFileSync(path.join(__dirname, 'config/certs', 'key.pem')),
        cert: fs.readFileSync(path.join(__dirname, 'config/certs', 'cert.pem'))
    };
    console.log('Using PEM certificates from certs/');
    console.log('Client cert authentication: DISABLED (no P12 file configured)');
}

console.log(`Header logging: ${LOG_HEADERS ? 'ENABLED' : 'DISABLED'} (set LOG_HEADERS=true to enable)`);

const MIME_TYPES = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

// Create proxy handler with configuration
const handleProxy = createProxyHandler(clientCertOptions, LOG_HEADERS);

// Helper to read request body
function readBody(req) {
    return new Promise((resolve) => {
        let body = '';
        req.on('data', chunk => { body += chunk; });
        req.on('end', () => resolve(body));
    });
}

const server = https.createServer(serverOptions, async (req, res) => {
    // ── API Routes ──────────────────────────────────────────────────

    // Proxy endpoint
    if (req.method === 'POST' && req.url === '/api/proxy') {
        const body = await readBody(req);
        handleProxy(req, res, body);
        return;
    }

    // Subscription endpoints
    if (req.method === 'GET' && req.url.startsWith('/api/subscription/')) {
        handleGetSubscription(req, res, DATA_DIR);
        return;
    }

    if (req.method === 'POST' && req.url === '/api/subscription') {
        const body = await readBody(req);
        handlePostSubscription(req, res, body, DATA_DIR);
        return;
    }

    // Queries endpoint
    if (req.method === 'POST' && req.url === '/api/queries') {
        const body = await readBody(req);
        handlePostQueries(req, res, body, DATA_DIR);
        return;
    }

    // Mulesoft config endpoints
    if (req.method === 'GET' && req.url.startsWith('/api/mulesoft/config/')) {
        handleGetMulesoftConfig(req, res, DATA_DIR);
        return;
    }

    if (req.method === 'POST' && req.url === '/api/mulesoft/config') {
        const body = await readBody(req);
        handlePostMulesoftConfig(req, res, body, DATA_DIR);
        return;
    }

    // Mulesoft proxy endpoint
    if (req.method === 'POST' && req.url === '/api/mulesoft/proxy') {
        const body = await readBody(req);
        handleMulesoftProxy(req, res, body, DATA_DIR, LOG_HEADERS);
        return;
    }

    // Clients import endpoint
    if (req.method === 'POST' && req.url === '/api/clients/import') {
        const body = await readBody(req);
        handleImportClients(req, res, body, DATA_DIR);
        return;
    }

    // AppConfig capacity endpoints
    if (req.method === 'POST' && req.url === '/api/appconfig/capacity') {
        const body = await readBody(req);
        handleFetchCapacity(req, res, body, DATA_DIR);
        return;
    }

    if (req.method === 'POST' && req.url === '/api/appconfig/report') {
        const body = await readBody(req);
        handleGenerateReport(req, res, body, DATA_DIR);
        return;
    }

    // Downloads endpoints - fetch results and save as gzip
    if (req.method === 'POST' && req.url === '/api/downloads/fetch') {
        const body = await readBody(req);
        handleFetchResults(req, res, body, DATA_DIR, clientCertOptions, LOG_HEADERS);
        return;
    }

    // View XML from saved gzip file
    if (req.method === 'GET' && req.url.startsWith('/api/downloads/view/')) {
        handleViewXml(req, res, DATA_DIR);
        return;
    }

    // List downloaded files
    if (req.method === 'GET' && req.url === '/api/downloads/list') {
        handleListDownloads(req, res, DATA_DIR);
        return;
    }

    // App APIs endpoints
    if (req.method === 'GET' && req.url === '/api/app-apis') {
        handleListAppApis(req, res, DATA_DIR);
        return;
    }

    if (req.method === 'GET' && req.url.startsWith('/api/app-apis/search')) {
        handleSearchAppApis(req, res, DATA_DIR);
        return;
    }

    if (req.method === 'GET' && req.url.match(/^\/api\/app-apis\/[^\/]+$/)) {
        handleGetAppApis(req, res, DATA_DIR);
        return;
    }

    if (req.method === 'POST' && req.url === '/api/app-apis/execute') {
        const body = await readBody(req);
        handleExecuteAppApi(req, res, body, DATA_DIR, clientCertOptions, LOG_HEADERS);
        return;
    }

    if (req.method === 'POST' && req.url.match(/^\/api\/app-apis\/[^\/]+$/)) {
        const body = await readBody(req);
        handleSaveAppApis(req, res, body, DATA_DIR);
        return;
    }

    // OPTIONS pre-flight
    if (req.method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        });
        res.end();
        return;
    }

    // ── Static file server ──────────────────────────────────────────
    let filePath;

    if (req.url === '/' || req.url === '/app' || req.url === '/app/') {
        // Root and /app serve the main HTML
        filePath = path.join(__dirname, 'app', 'smd2.html');
    } else if (req.url.startsWith('/app/')) {
        // Explicit /app/ paths
        filePath = path.join(__dirname, req.url);
    } else if (req.url.startsWith('/data/')) {
        // Data directory access
        filePath = path.join(__dirname, req.url);
    } else {
        // All other static assets served from app directory
        filePath = path.join(__dirname, 'app', req.url);
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (err, content) => {
        if (err) {
            if (err.code === 'ENOENT') {
                res.writeHead(404, { 'Content-Type': 'text/plain' });
                res.end('404 Not Found');
            } else {
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end('500 Internal Server Error');
            }
            return;
        }

        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
    });
});

server.listen(PORT, () => {
    console.log(`HTTPS server running at https://localhost:${PORT}/app`);
});
